package vn.reborn.api.model;

import lombok.Data;
import lombok.experimental.Accessors;
import vn.reborn.core.model.SearchRequest;
import vn.reborn.core.model.paging.Pageable;

import java.util.List;

@Data
@Accessors(chain = true)
public class DfListResponse<T> {
    private Integer code;
    private String message;
    private ResultResponse<T> result;

    public DfListResponse(String message, Pageable pageable, List<T> result) {
        this.code = 200;
        this.message = message;
        this.result = new ResultResponse<T>()
                .setCurrentPage(pageable.getPage())
                .setPerPage(pageable.getPageSize())
                .setTotal(pageable.getTotal())
                .setData(result);
    }

    public DfListResponse(Pageable pageable, List<T> result) {
        this.code = 200;
        this.message = "Thành công";
        this.result = new ResultResponse<T>()
                .setCurrentPage(pageable.getPage())
                .setPerPage(pageable.getPageSize())
                .setTotal(pageable.getTotal())
                .setData(result);
    }

    public DfListResponse(SearchRequest searchRequest, List<T> result) {
        this.code = 200;
        this.message = "Thành công";
        this.result = new ResultResponse<T>()
                .setCurrentPage(searchRequest.getPage())
                .setPerPage(searchRequest.getPageSize())
                .setTotal(searchRequest.getTotal() )
                .setData(result);
    }
}
