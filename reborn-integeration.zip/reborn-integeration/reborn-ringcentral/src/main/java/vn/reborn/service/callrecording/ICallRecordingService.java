package vn.reborn.service.callrecording;

import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;

public interface ICallRecordingService {

    @SneakyThrows
    Single<byte[]> getCallRecordingContent(String recordingId, ReadCallRecordingContentParameters readCallRecordingContentParameters);

    @SneakyThrows
    Single<GetCallRecordingResponse> getCallRecording(String recordingId);
}
