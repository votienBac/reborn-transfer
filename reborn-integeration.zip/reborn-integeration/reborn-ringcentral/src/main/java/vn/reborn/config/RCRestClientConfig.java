package vn.reborn.config;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.AuthorizeRequest;
import com.ringcentral.definitions.GetTokenRequest;
import com.ringcentral.paths.restapi.account.Index;
import lombok.SneakyThrows;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RCRestClientConfig {
    private RCConfig rcConfig;

    public RCRestClientConfig(RCConfig rcConfig) {
        this.rcConfig = rcConfig;
    }

    @SneakyThrows
    @Bean
    public RestClient client() {
        RestClient rc = new RestClient(rcConfig.getClientId(), rcConfig.getSecretId(), rcConfig.getServer());
//        rc.authorize(rc?Config.getAccessToken());
        return rc;
    }

    @Bean
    public Index account() {
        return client().restapi().account();
    }

    @SneakyThrows
    @Bean
    public AuthorizeRequest authorizationUrl() {
        return new AuthorizeRequest()
                .client_id(rcConfig.getClientId())
                .redirect_uri(rcConfig.getRedirectUrl())
                .response_type("code");

    }
}
