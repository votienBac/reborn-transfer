package vn.reborn.service.oauth;

import com.ringcentral.definitions.TokenInfo;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;

public interface IOAuthService {
    @SneakyThrows
    Single<String> generateOAuthRequest();

    @SneakyThrows
    Single<TokenInfo> codeToAccessToken(String code);

    @SneakyThrows
    Single<TokenInfo> refreshToken(String refreshToken);
}
