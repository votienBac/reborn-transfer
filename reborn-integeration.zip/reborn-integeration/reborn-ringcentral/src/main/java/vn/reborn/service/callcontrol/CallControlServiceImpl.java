package vn.reborn.service.callcontrol;

import com.ringcentral.definitions.CallParty;
import com.ringcentral.definitions.CallRecording;
import com.ringcentral.definitions.CallRecordingUpdate;
import com.ringcentral.definitions.ForwardTarget;
import com.ringcentral.paths.restapi.account.Index;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import static vn.reborn.core.template.RxTemplate.rxSchedulerIo;

@Log4j2
@Service
public class CallControlServiceImpl implements ICallControlService {
    private final Index account;

    public CallControlServiceImpl(Index account) {
        this.account = account;
    }

    @SneakyThrows
    @Override
    public Single<CallParty> forwardIncomingCall(String telephonySessionId,
                                                 String partyId,
                                                 ForwardTarget forwardTarget) {
        return rxSchedulerIo(() -> account
                .telephony()
                .sessions(telephonySessionId)
                .parties(partyId)
                .forward().post(forwardTarget));
    }

    @SneakyThrows
    @Override
    public Single<String> createRecording(String telephonySessionId, String partyId) {
        return rxSchedulerIo(() -> {
            String response = account.telephony().sessions(telephonySessionId).parties(partyId).recordings().post();
            return response;
        });
    }

    @SneakyThrows
    @Override
    public Single<CallRecording> pauseResumeRecording(String telephonySessionId, String partyId, String recordingId, CallRecordingUpdate callRecordingUpdate) {
        return rxSchedulerIo(() -> {
            CallRecording response = account.telephony().sessions(telephonySessionId).parties(partyId).recordings(recordingId).patch(callRecordingUpdate);
            return response;
        });
    }

    @SneakyThrows
    @Override
    public Single<String> rejectCall(String telephonySessionId, String partyId) {
        return rxSchedulerIo(() -> {
            String response = account.telephony().sessions(telephonySessionId).parties(partyId).reject().post();
            return response;
        });
    }
}
