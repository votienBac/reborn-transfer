package vn.reborn.service.callrecording;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.core.template.RxTemplate;

@Log4j2
@Service
public class CallRecordingServiceImpl implements ICallRecordingService {
    private final RestClient rc;

    public CallRecordingServiceImpl(RestClient rc) {
        this.rc = rc;
    }

    @SneakyThrows
    @Override
    public Single<byte[]> getCallRecordingContent(String recordingId, ReadCallRecordingContentParameters readCallRecordingContentParameters){
        return RxTemplate.rxSchedulerIo(() ->{
            byte[] response = rc.restapi().account().recording(recordingId).content().get(readCallRecordingContentParameters);
            return response;
        });
    }
    @SneakyThrows
    @Override
    public Single<GetCallRecordingResponse> getCallRecording(String recordingId){
        return RxTemplate.rxSchedulerIo(() ->{
            GetCallRecordingResponse response = rc.restapi().account().recording(recordingId).get();
            return response;
        });
    }

}
