package vn.reborn.service.callfwd;

import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;

public interface ICallForwardingService {
    @SneakyThrows
    Single<ForwardingNumberInfo> create(CreateForwardingNumberRequest request);

    @SneakyThrows
    Single<ForwardingNumberInfo> update(UpdateForwardingNumberRequest request);

    @SneakyThrows
    Single<String> delete(DeleteForwardingNumbersRequest request);

    @SneakyThrows
    Single<GetExtensionForwardingNumberListResponse> search(ListForwardingNumbersParameters request);

    @SneakyThrows
    Single<ForwardingNumberResource> getByID(String id);
}
