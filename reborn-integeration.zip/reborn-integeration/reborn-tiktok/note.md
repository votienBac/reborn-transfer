Oauth get access token
![img_3.png](img_3.png)
![img_4.png](img_4.png)

    import com.fasterxml.jackson.core.JsonProcessingException;
    import com.fasterxml.jackson.databind.ObjectMapper;
    import okhttp3.*;
    import org.apache.http.client.utils.URIBuilder;
    
    import java.io.IOException;
    import java.net.URI;
    import java.net.URISyntaxException;
    import java.net.URL;
    import java.util.List;
    import java.util.Map;
    import java.util.stream.Collectors;
    
    public class Demo {
    private static final String ACCESS_TOKEN = "xxx";
    private static final String PATH = "/open_api/oauth2/access_token/";
    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * Build request URL
     *
     * @param path Request path
     * @return Request URL
     */
    private static String buildUrl(String path) throws URISyntaxException {
        URI uri = new URI("https", "business-api.tiktok.com", path, "", "");
        return uri.toString();
    }


    /**
     * Send POST request
     *
     * @param jsonStr Args in JSON format
     * @return Response in JSON format
     */
    private static String post(String jsonStr) throws IOException, URISyntaxException {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        String url = buildUrl(PATH);

        RequestBody body = RequestBody.create(MediaType.parse("application/json"), jsonStr);
        Request request = new Request.Builder()
                .url(url)
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .build();
        Response response = client.newCall(request).execute();
        return response.body().string();
    }

    public static void main(String[] args) throws IOException, URISyntaxException {
        String secret = SECRET;
        String app_id = APP_ID;
        String auth_code = AUTH_CODE;

        // Args in JSON format
        String myArgs = String.format("{\"secret\": \"%s\", \"app_id\": \"%s\", \"auth_code\": \"%s\"}",secret, app_id, auth_code);
        System.out.println(post(myArgs));
    }
    }

Revoke an access token
Use this endpoint to revoke an access token. This is a new endpoint in TikTok API for Business v1.3.

You need to first generate an access token via /oauth2/access_token/ or /oauth/token/.

Request
Endpoint https://business-api.tiktok.com/open_api/v1.3/oauth2/revoke_token/

![img.png](img.png)

![img_1.png](img_1.png)
![img_2.png](img_2.png)
