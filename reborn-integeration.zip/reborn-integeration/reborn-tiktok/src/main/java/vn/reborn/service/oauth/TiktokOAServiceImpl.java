package vn.reborn.service.oauth;

import io.reactivex.rxjava3.core.Single;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.config.TiktokConfig;
import vn.reborn.core.exception.ApiException;
import vn.reborn.core.http.OkHttpService;
import vn.reborn.data.request.tiktok.oauth.GetAccessTokenRQ;
import vn.reborn.data.response.tiktok.oauth.AccessTokenResponse;

import static vn.reborn.data.constant.TiktokConstant.BASE_URL;
import static vn.reborn.data.constant.TiktokConstant.PATH_GET_ACCESS_TOKEN;

@Log4j2
@Service
public class TiktokOAServiceImpl implements ITiktokOAService {
    private final OkHttpService okHttpService;
    private final TiktokConfig tiktokConfig;

    public TiktokOAServiceImpl(OkHttpService okHttpService, TiktokConfig tiktokConfig) {
        this.okHttpService = okHttpService;
        this.tiktokConfig = tiktokConfig;
    }
    @Override
    public Single<AccessTokenResponse> getAccessToken(GetAccessTokenRQ request) {
        String url = BASE_URL + PATH_GET_ACCESS_TOKEN;
        return okHttpService.postJson(url,
                request.setAppId(tiktokConfig.getAppId())
                        .setSecret(tiktokConfig.getSecretId()),
                AccessTokenResponse.class)
                .flatMap(optRS -> optRS.<io.reactivex.rxjava3.core.SingleSource<? extends AccessTokenResponse>>map(Single::just)
                        .orElseGet(() -> Single.error(new ApiException("Get accesstoken fail"))));
//                .flatMap(save to db);
    }

    @Override
    public Single<String> getUrlAuthorize() {
        return Single.just(tiktokConfig.getAuthorizeUrl());
    }


}
