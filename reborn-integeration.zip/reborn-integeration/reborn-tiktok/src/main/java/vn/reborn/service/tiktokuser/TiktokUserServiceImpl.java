package vn.reborn.service.tiktokuser;

import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.config.TiktokConfig;
import vn.reborn.core.exception.ApiException;
import vn.reborn.core.http.OkHttpService;
import vn.reborn.data.response.tiktok.oauth.AccessTokenResponse;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static vn.reborn.data.constant.TiktokConstant.BASE_URL;
import static vn.reborn.data.constant.TiktokConstant.PATH_GET_ACCESS_TOKEN;

@Log4j2
@Service
public class TiktokUserServiceImpl implements ITiktokUserService {
    private final OkHttpService okHttpService;
    private final TiktokConfig tiktokConfig;

    public TiktokUserServiceImpl(OkHttpService okHttpService, TiktokConfig tiktokConfig) {
        this.okHttpService = okHttpService;
        this.tiktokConfig = tiktokConfig;
    }
    @SneakyThrows
    @Override
    public Single<AccessTokenResponse> getUserInfo(String accessToken) {
        URL url = new URL(BASE_URL + PATH_GET_ACCESS_TOKEN);
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Token", accessToken);
        return okHttpService.get(url,
                headers,
                AccessTokenResponse.class)
                .flatMap(optRS -> optRS.<io.reactivex.rxjava3.core.SingleSource<? extends AccessTokenResponse>>map(Single::just)
                        .orElseGet(() -> Single.error(new ApiException("Get accesstoken fail"))));
//                .flatMap(save to db);
    }



}
