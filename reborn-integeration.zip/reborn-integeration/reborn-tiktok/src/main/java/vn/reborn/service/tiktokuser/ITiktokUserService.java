package vn.reborn.service.tiktokuser;

import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import vn.reborn.data.response.tiktok.oauth.AccessTokenResponse;

public interface ITiktokUserService {
    @SneakyThrows
    Single<AccessTokenResponse> getUserInfo(String accessToken);
}
