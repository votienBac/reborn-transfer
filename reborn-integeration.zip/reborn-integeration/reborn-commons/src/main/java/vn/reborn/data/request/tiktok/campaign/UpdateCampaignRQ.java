package vn.reborn.data.request.tiktok.campaign;

import lombok.Data;
import lombok.SneakyThrows;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@Accessors(chain = true)
public class UpdateCampaignRQ {
    @NotNull
    private String advertiserId;
    @NotNull
    private String campaignId;
    private String campaignName;
    private List<String> specialIndustries;
    private Float budget;

}
