package vn.reborn.data.model;

public class OAuthRequest {
    public String server;
    public String clientId;
    public String redirectUrl;
    public static final String responseType = "code";

    public String authorizeUrl;
}
