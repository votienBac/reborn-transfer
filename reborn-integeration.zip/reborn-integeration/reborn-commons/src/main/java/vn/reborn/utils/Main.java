package vn.reborn.utils;

import io.reactivex.rxjava3.core.Single;
import lombok.extern.log4j.Log4j2;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;
import static vn.reborn.core.template.RxTemplate.rxSchedulerIo;

@Log4j2
public class Main {
    public static void main(String[] args) {
        final Single<List<Integer>> task1 = rxSchedulerIo(() -> {
            final String name = Thread.currentThread().getName();

            for (Integer integer : Arrays.asList(1, 2, 3, 4, 5)) {
                log.info("[thread 1] name - {} value: {}", name, integer);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (integer == 3) throw new Exception();
            }
            return asList(1, 2, 3, 4, 5);
        });
        final Single<List<Integer>> task2 = rxSchedulerIo(() -> {
            final String name = Thread.currentThread().getName();
            return asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
                    .stream()
                    .map(integer -> {
                        log.info("[thread 2] name - {} value: {}", name, integer);
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return integer;
                    })
                    .collect(Collectors.toList());
        });

        Single
                .zip(
                        task1, task2,
                        (integer, integer2) -> {
                            log.info("[DONE]");
                            return 1;
                        })
                .onErrorReturn(throwable -> 100)
                .subscribe((integer, throwable) -> {
                    log.info("[result] {}", integer);
                    log.error(throwable);
                });
//
//        Observable.just("io")
//                .subscribeOn(Schedulers.io())
//                .subscribe(i -> log.info("value {}, thread {} ", i, Thread.currentThread().getName()));
        System.out.println("begin!");
        while (true) {
            System.out.println("done");
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
