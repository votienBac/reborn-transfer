package vn.reborn.data.request.tiktok.oauth;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class GetAccessTokenRQ {
    private String appId;
    private String secret;
    private String authCode;

}
