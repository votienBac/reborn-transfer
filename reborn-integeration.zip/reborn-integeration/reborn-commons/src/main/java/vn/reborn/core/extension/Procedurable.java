package vn.reborn.core.extension;

@FunctionalInterface
public interface Procedurable {
    public void process();
}
