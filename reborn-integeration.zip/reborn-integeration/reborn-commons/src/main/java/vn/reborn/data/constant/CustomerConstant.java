package vn.reborn.data.constant;

public class CustomerConstant {
    public static String GUEST = "Khách lẻ";
}
