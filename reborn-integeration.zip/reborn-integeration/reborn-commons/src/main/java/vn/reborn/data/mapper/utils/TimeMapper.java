package vn.reborn.data.mapper.utils;

import org.mapstruct.Mapper;
import vn.reborn.utils.TimeUtil;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Mapper(componentModel = "spring")
public abstract class TimeMapper {
    public Long map(LocalDate localDate) {
        return TimeUtil.localDateToLong(localDate);
    }

    public LocalDate map(Long localDate) {
        return TimeUtil.longToLocalDateOrNow(localDate);
    }

    public LocalDateTime longToLocalDateTime(Long localDate) {
        return TimeUtil.longToLocalDateTimeOrNow(localDate);
    }

    public Long map(LocalDateTime localDateTime) {
        return TimeUtil.localDateTimeToLong(localDateTime);
    }
}
