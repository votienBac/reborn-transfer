package vn.reborn.data.response.tiktok.campaign;

import lombok.Data;
import lombok.experimental.Accessors;
import vn.reborn.data.model.tiktok.CampaignInfo;
import vn.reborn.data.model.tiktok.PageInfo;


@Data
@Accessors(chain = true)
public class CreateCampaignRS {
    private Integer code;
    private String message;
    private String requestId;
    private CampaignInfo data;
    private PageInfo pageInfo;
}
