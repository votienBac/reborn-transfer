package vn.reborn.data.enums;


import lombok.Getter;

@Getter
public enum UsersUserType {

    owner("owner"),

    emloyee("emloyee");

    private final String literal;

    UsersUserType(String literal) {
        this.literal = literal;
    }


}
