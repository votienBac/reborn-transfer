package vn.reborn.data.model.tiktok;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CampaignInfo {
    private String advertiserId;
    private String campaignid;
    private String createTime;
    private String modifyTime;
    private String objectiveType;
    private String appPromotionType;
    private String isSearchCampaign;
    private Boolean isSmartPerformanceCampaign;
    private String campaignType;
    private String appId;
    private String campaignAppProfilePageState;
    private String rfCampaignType;
    private String campaignProductSource;
    private String campaignName;
    private String specialIndustries;
    private Boolean budgetOptimizeOn;
    private Integer bidType;
    private String deepBidType;
    private float roasBid;
    private String optimizationGoal;
    private String budgetMode;
    private Float budget;
    private String operationStatus;
    private String secondaryStatus;
    private Boolean isNewStructure;
    private String objective;
}
