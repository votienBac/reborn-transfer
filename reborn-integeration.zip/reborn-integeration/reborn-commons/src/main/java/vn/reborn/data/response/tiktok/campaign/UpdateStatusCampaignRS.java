package vn.reborn.data.response.tiktok.campaign;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
public class UpdateStatusCampaignRS {
    private Integer code;
    private String message;
    private DataDTO data;
    @Data
    @Accessors(chain = true)
    public static class DataDTO {
        private String status;
        private List<String> campaignIds;
        private List<CampaignDTO> campaignList;
        private String requestId;
    }
    @Data
    @Accessors(chain = true)
    public static class CampaignDTO{
        private String campaignId;
        private String postbackWindowMode;
        private String status;
    }
}
