package vn.reborn.data.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;
import vn.reborn.utils.CollectionUtils;

import static vn.reborn.utils.CollectionUtils.getOrDefault;


@Data
@Accessors(chain = true)
public class AmountStatisticDTO {
    @Schema(title = "Tổng tiền")
    private Long amount;
    @Schema(title = "Đã thanh toán")
    private Long payAmount;
    @Schema(title = "Giảm giá")
    private Long discount;
    @Schema(title = "VAT")
    private Long vatAmount;
    @Schema(title = "Công nợ")
    private Long debt;

    public Long getDebt() {
        return CollectionUtils.getOrDefault(amount, 0L) - CollectionUtils.getOrDefault(payAmount, 0L);
    }
}
