package vn.reborn.data.enums;

import lombok.Getter;

@Getter
public enum CheckStatus {

    pending("pending"),

    deny("deny"),

    checked("checked");

    private final String literal;

    CheckStatus(String literal) {
        this.literal = literal;
    }

}
