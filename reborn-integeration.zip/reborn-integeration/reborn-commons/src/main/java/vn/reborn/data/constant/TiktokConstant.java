package vn.reborn.data.constant;

public class TiktokConstant {
    private TiktokConstant() {

    }
    public static final String PATH_GET_ACCESS_TOKEN ="/open_api/v1.3/oauth2/access_token/";

    public static final String BASE_URL = "https://business-api.tiktok.com";
    public static final String BASE_URL_SANDBOX = "https://sandbox-ads.tiktok.com";
    public static final String PATH_GET_USER_INFO ="/open_api/v1.3/user/info";
    public static final String PATH_CREATE_CAMPAIGN ="/open_api/v1.3/campaign/create";
    public static final String PATH_UPDATE_CAMPAIGN ="/open_api/v1.3/campaign/update";
    public static final String PATH_UPDATE_STATUS_CAMPAIGN ="/open_api/v1.3/campaign/status/update";
    public static final String PATH_GET_CAMPAIGN ="/open_api/v1.3/campaign/get";

}
