package vn.reborn.api.mapper;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.jooq.JSONB;
import org.mapstruct.Context;
import org.mapstruct.IterableMapping;
import org.mapstruct.Named;
import org.springframework.security.core.Authentication;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static vn.reborn.utils.TimeUtil.parserToLocalDateTime;

public interface IMapper<Rq, Rs, Pojo> {
    @Named("toPojo")
    public Pojo toPojo(Rq request, @Context Authentication authentication);

    @IterableMapping(qualifiedByName = "toPojo")
    public List<Pojo> toListPojo(List<Rq> requestList, @Context Authentication authentication);

    Rs toResponse(Pojo pojo);

    @Named("toPojo")
    Rs toResponse(Pojo pojo, @Context Authentication authentication);

    @IterableMapping(qualifiedByName = "toPojo")
    public List<Rs> toResponses(List<Pojo> pojos, @Context Authentication authentication);

    default LocalDateTime mapToLocalDateTime(String input) {
        return parserToLocalDateTime(input);
    }

    default LocalDate mapToLocalDate(String input) {
        LocalDateTime localDateTime = parserToLocalDateTime(input);
        if (localDateTime == null) {
            return null;
        }
        return localDateTime.toLocalDate();
    }

    default Long stringToLong(String input) {
        if (StringUtils.isEmpty(input) || !NumberUtils.isDigits(input)) return null;
        return NumberUtils.createLong(input);
    }

    default String map(JSONB jsonb) {
        if (jsonb == null) return null;
        return jsonb.data();
    }
}
