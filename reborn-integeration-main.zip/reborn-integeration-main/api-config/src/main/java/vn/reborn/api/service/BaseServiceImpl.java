package vn.reborn.api.service;

import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import org.jooq.Condition;
import org.jooq.impl.DSL;
import org.springframework.security.core.Authentication;
import vn.reborn.api.mapper.IMapper;
import vn.reborn.core.exception.ApiException;
import vn.reborn.core.model.SearchRequest;
import vn.reborn.core.model.paging.Order;
import vn.reborn.core.model.paging.Pageable;
import vn.reborn.repository.IBaseRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.util.Arrays.asList;
import static vn.reborn.data.constant.MessageResponse.*;

public abstract class BaseServiceImpl<Rq, Rs, Pojo, I> implements IService<Rq, Rs, I> {
    protected final IMapper<Rq, Rs, Pojo> mapper;
    protected final IBaseRepository<Pojo, I> repository;

    protected BaseServiceImpl(IMapper<Rq, Rs, Pojo> mapper,
                              IBaseRepository<Pojo, I> repository) {
        this.mapper = mapper;
        this.repository = repository;
    }

    @Override
    public Single<Rs> findById(I id, Authentication authentication) {
        return repository.findById(id)
                .flatMap(pojoOptional -> toResponse(pojoOptional, authentication, RESOURCE_NOT_FOUND))
                .flatMap(rs -> addExtraInfo(rs, authentication));
    }

    @Override
    public Single<Rs> insert(Rq request, Authentication authentication) {
        return repository.insertReturning(mapper.toPojo(request, authentication))
                .flatMap(pojoOptional -> toResponse(pojoOptional, authentication, INSERT_FAIL))
                .flatMap(rs -> addExtraInfo(rs, authentication));
    }

    private Single<Rs> toResponse(Optional<Pojo> pojoOptional, Authentication authentication, String message) {
        return pojoOptional
                .map((Pojo pojo) -> mapper.toResponse(pojo, authentication))
                .map(Single::just)
                .orElse(Single.error(new ApiException(message)));
    }

    @Override
    public Single<Rs> update(I id, Rq request, Authentication authentication) {
        return validBeforeUpdate(id, request, authentication)
                .flatMap(rq -> repository.update(id, mapper.toPojo(rq, authentication)))
                .flatMap(integer -> repository.findById(id))
                .flatMap(pojoOptional -> toResponse(pojoOptional, authentication, INSERT_FAIL))
                .flatMap(rs -> addExtraInfo(rs, authentication));
    }

    protected @NonNull Single<Rq> validBeforeUpdate(I id, Rq request, Authentication authentication) {
        return Single.just(request);
    }

    @Override
    public Single<Boolean> delete(I id, Authentication authentication) {
        return deletableObject(id, authentication)
                .flatMap(isValid -> !isValid ?
                        Single.error(new ApiException(NOT_PERMISSION)) :
                        repository.deletedById(id))
                .map(integer -> integer > 0);
    }

    protected Single<Boolean> deletableObject(I id, Authentication authentication) {
        return Single.just(true);
    }


    @Override
    public Single<List<Rs>> list(Pageable pageable, Authentication authentication, boolean withExtraInfo) {
        standardizedSort(pageable, new Order("id", Order.Direction.desc.name()));
        return Single.zip(
                        repository.getActiveByPageable(pageable,
                                searchCondition(pageable.getKeyword(), authentication)),
                        repository.countActive(pageable.getFilters(),
                                searchCondition(pageable.getKeyword(), authentication)),
                        (pojos, total) -> {
                            pageable.setTotal(total);
                            return mapper.toResponses(pojos, authentication);
                        })
                .flatMap(rs -> withExtraInfo ? addExtraInfo(rs, authentication) : Single.just(rs));
    }

    @Override
    public Single<List<Rs>> search(SearchRequest searchRequest, Authentication authentication) {
        return Single.zip(
                        repository.getActiveBySearchRequest(searchRequest,
                                searchCondition(searchRequest.getKeyword(), authentication)),
                        repository.countBySearchRequest(searchRequest,
                                searchCondition(searchRequest.getKeyword(), authentication)),
                        (pojos, total) -> {
                            searchRequest.setTotal(total);
                            return mapper.toResponses(pojos, authentication);
                        })
                .flatMap(rs -> addExtraInfo(rs, authentication));
    }

    @Override
    public Single<Rs> addExtraInfo(Rs rs, Authentication authentication) {
        return addExtraInfo(asList(rs), authentication)
                .map(rs1 -> rs);
    }

    @Override
    public Single<List<Rs>> addExtraInfo(List<Rs> rs, Authentication authentication) {
        return Single.just(rs);
    }

    protected Condition searchCondition(String keyword, Authentication authentication) {
        return DSL.trueCondition();
    }

    @Override
    public Single<List<Rs>> exportPage(SearchRequest request, Authentication authentication) {
        return Single.zip(
                repository.getActiveBySearchRequest(request, searchCondition(null, authentication)),
                repository.countActive(searchCondition(null, authentication)),
                (pojos, total) -> {
                    request.setTotal(total);
                    return mapper.toResponses(pojos, authentication);
                });
    }

    @Override
    public Single<List<Rs>> exportSearch(SearchRequest request, Authentication authentication) {
        return Single.zip(
                repository.getActiveByCondition(searchCondition(request.getKeyword(), authentication)),
                repository.countActive(searchCondition(request.getKeyword(), authentication)),
                (pojos, total) -> {
                    request.setTotal(total);
                    return mapper.toResponses(pojos, authentication);
                });
    }

    @Override
    public Single<List<Rs>> exportAll(SearchRequest searchRequest, Authentication authentication) {
        return Single.zip(
                repository.getActiveByCondition(searchCondition(null, authentication)),
                repository.countActive(searchCondition(null, authentication)),
                (pojos, total) -> {
                    searchRequest.setTotal(total);
                    return mapper.toResponses(pojos, authentication);
                });
    }

    protected void standardizedSort(Pageable pageable, Order order) {
        if (pageable.getSorts() == null) {
            pageable.setSorts(new ArrayList<>());
        }
        if (pageable.getSorts().isEmpty()) {
            pageable.getSorts().add(order);
        }
    }

    protected void standardizedSort(SearchRequest searchRequest, Order order) {
        if (searchRequest.getSorts() == null) {
            searchRequest.setSorts(new ArrayList<>());
        }
        if (searchRequest.getSorts().isEmpty()) {
            searchRequest.getSorts().add(order);
        }
    }
}
