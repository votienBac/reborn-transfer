package vn.reborn.data.response.tiktok.oauth;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
public class AccessTokenResponse {
    private Integer code;
    private String message;
    private String requestId;
    private DataRS data;
    @Data
    @Accessors(chain = true)
    public static class DataRS{
        private String accessToken;
        private List<String> advertiserIds;
        private List<Integer>   scope;
    }
}
