package vn.reborn.data.dto;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class NumberDTO {
    private Long drugId;
    private Long unitId;
    private String number;
    private Long drugStoreId;
}
