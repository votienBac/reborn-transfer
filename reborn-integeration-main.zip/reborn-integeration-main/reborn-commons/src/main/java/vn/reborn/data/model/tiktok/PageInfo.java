package vn.reborn.data.model.tiktok;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class PageInfo {
    private Integer page;
    private Integer pageSize;
    private Integer totalNumber;
    private Integer totalPage;
}
