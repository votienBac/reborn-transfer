package vn.reborn.data.constant;

public class SEOConstants {
    //Định nghĩa độ dài của bài viết
    public static final int TITLE = 60;
    public static final int DESCRIPTION = 160;
    public static final int LINK = 75;
}
