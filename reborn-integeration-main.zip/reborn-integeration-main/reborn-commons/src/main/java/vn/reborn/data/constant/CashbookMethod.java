package vn.reborn.data.constant;

public enum CashbookMethod {
    manual, auto
}
