package vn.reborn.data.enums;


import lombok.Getter;


@Getter
public enum InvoicePaymentStatus {

    unpaid("unpaid"),

    paid_path("paid_path"),

    paid("paid");

    private final String literal;

    InvoicePaymentStatus(String literal) {
        this.literal = literal;
    }

}
