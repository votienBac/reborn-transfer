package vn.reborn.data.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MessageResponse {
    public static final String SUCCESS = "Thành cônng";
    public static final String FAIL = "Thất bại";
    public static final String RESOURCE_NOT_FOUND = "resource not found!";
    public static final String DRUG_NOT_FOUND = "Thuộc không tồn tại";
    public static final String USER_PASS_INVALID = "Username or password invalid.";
    public static final String INSERT_FAIL = "fail to insert!";
    public static final String UPDATE_FAIL = "fail to update!";
    public static final String ID_MUST_NOT_BE_NULL = "ID_MUST_NOT_BE_NULL";
    public static final String CREATED_MUST_NOT_BE_NULL = "CREATED_MUST_NOT_BE_NULL";
    public static final String NOT_PERMISSION = "Bạn không có quyền thực hiện thao tác này";
    public static final String INVOICE_NOT_FOUND = "Không tìm thấy hóa đơn";
    public static final String INVOICE_CANCELED = "Hoá đơn đã huỷ";
    public static final String INVOICE_STATUS_ALREAD_EXITED = "Hoá đơn đang ở trạng thái này";
    public static final String INVOICE_STATUS_NOT_VALID = "Trạng thái hóa đơn không hợp lệ";
    public static final String CASH_BOOK_TYPE_INVALID = "Loại thu chi không hợp lệ";
    public static final String INVALID_DATE = "Định dạng ngày không hợp lệ";
    public static final String INVOICE_STATUS_NO_CHANGE = "Trạng thái hoá đơn không thay đổi";
}
