package vn.reborn.data.enums;


import lombok.Getter;

@Getter
public enum WarehouseIsBasic {

    yes("yes", true, "master data: tự sinh khi thêm mới thuốc"),

    no("no", false, "stock: nhập kho");

    private final String literal;
    private final boolean value;

    WarehouseIsBasic(String literal, boolean value, String description) {
        this.literal = literal;
        this.value = value;
    }

    public Boolean value() {
        return value;
    }

}
