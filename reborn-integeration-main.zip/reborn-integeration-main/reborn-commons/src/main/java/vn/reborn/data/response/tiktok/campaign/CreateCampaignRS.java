package vn.reborn.data.response.tiktok.campaign;

public class CreateCampaignRS {
}
