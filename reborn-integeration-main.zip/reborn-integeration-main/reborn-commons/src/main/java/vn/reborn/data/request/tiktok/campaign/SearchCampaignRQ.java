package vn.reborn.data.request.tiktok.campaign;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
public class SearchCampaignRQ {
    private String advertiserId;
    private List<String> fields;
    private List<String> excludeFieldTypesInResponse;
    private Filtering filtering;
    private Integer page;
    private Integer pageSize;
    @Data
    @Accessors(chain = true)
    public static class Filtering {
        private List<String> campaignIds;
        private String campaignName;
        private String primaryStatus;
        private String secondaryStatus;
        private String objectiveType;
        private String campaignType;
        private String appPromotionType;
        private Boolean isSmartPerformanceCampaign;
        private String campaignProductSource;
        private String optimizationGoal;
        private String createFilterStartTime;
        private String createFilterEndTime;

    }
}
