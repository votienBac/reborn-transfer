package vn.reborn.data.constant;

public class ESConstant {
    private ESConstant() {

    }
    public static final String WAREHOUSE_INDEX ="warehouse_index";

    public static final String USER_INDEX = "user_index";
    public static final String DRUG_INDEX = "drug_index";
    public static final String EXPIRED_TIME = "5m"; // 5 minutes
    public static final String UPDATED_AT = "updated_at";

}
