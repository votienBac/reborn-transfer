package vn.reborn.data.request.tiktok.campaign;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@Accessors(chain = true)
public class UpdateStatusCampaignRQ {
    @NotNull
    private String advertiserId;
    @NotNull
    private List<String> campaignIds;
    private String operationStatus;
    private String postbackWindowMode;

}
