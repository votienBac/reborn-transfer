package vn.reborn.data.enums;

import lombok.Getter;

@Getter
public enum BranchStatus {
    open("open"),

    close("close");

    private final String literal;

    private BranchStatus(String literal) {
        this.literal = literal;
    }

}
