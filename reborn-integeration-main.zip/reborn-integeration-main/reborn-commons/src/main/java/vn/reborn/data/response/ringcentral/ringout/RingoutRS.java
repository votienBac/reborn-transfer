package vn.reborn.data.response.ringcentral.ringout;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class RingoutRS {
    private Long id;
    private String uri;
    private Status status;
    @Data
    @Accessors(chain = true)
    public static class Status{
        private String callStatus;
        private String callerStatus;
        private String calleeStatus;
    }

}
