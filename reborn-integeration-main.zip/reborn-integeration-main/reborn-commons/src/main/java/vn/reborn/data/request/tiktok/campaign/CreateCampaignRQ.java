package vn.reborn.data.request.tiktok.campaign;

import lombok.Data;
import lombok.SneakyThrows;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotNull;

@Data
@Accessors(chain = true)
public class CreateCampaignRQ {
    @NotNull
    private String advertiserId;
    @NotNull
    private String objectiveType;
    @NotNull
    private String campaignName;
    private String appPromotionType;
    private String campaignType;
    private Float budget;
    private String budgetMode;
    private boolean budgetOptimizeOn;
    private String requestId;
    private String appId;
    private String campaignAppProfilePageState;
    private String rfCampaignType;
    private String campaingProductSource;


    @SneakyThrows
    public void setAppPromotionType(String appPromotionType){
        if(objectiveType == "APP_PROMOTION" && appPromotionType == null){
            throw new IllegalAccessException("App Promotion Type is required");
        }else this.appPromotionType = appPromotionType;
    }
}
