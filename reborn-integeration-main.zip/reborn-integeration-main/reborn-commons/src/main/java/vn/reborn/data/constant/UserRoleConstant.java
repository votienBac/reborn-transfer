package vn.reborn.data.constant;

public enum UserRoleConstant {
    admin,
    cashier,
    warehousing_manage,
    stock_manage,
    warehousing,
    sell_manage;
}
