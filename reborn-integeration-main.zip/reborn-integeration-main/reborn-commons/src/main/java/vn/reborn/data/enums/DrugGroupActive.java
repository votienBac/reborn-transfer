package vn.reborn.data.enums;


import lombok.Getter;

@Getter
public enum DrugGroupActive {

    yes("yes"),

    no("no");

    private final String literal;

    DrugGroupActive(String literal) {
        this.literal = literal;
    }

}
