package vn.reborn.data.constant;

public class TiktokConstant {
    private TiktokConstant() {

    }
    public static final String PATH_GET_ACCESS_TOKEN ="/open_api/oauth2/access_token/";

    public static final String BASE_URL = "https://business-api.tiktok.com";
    public static final String PATH_CREATE_CAMPAIGN ="/open_api/v1.3/campaign/create";

}
