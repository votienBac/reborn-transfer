package vn.reborn.data.enums;


import lombok.Getter;

@Getter
public enum CustomerGender {

    male("male"),

    fmale("fmale"),

    company("company");

    private final String literal;

    CustomerGender(String literal) {
        this.literal = literal;
    }


}
