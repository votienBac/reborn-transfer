package vn.reborn.data.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public abstract class InvoiceDrugReportDTO {
    @Schema(title = "ID của hóa đơn")
    private Long id;
    @Schema(title = "Mã hóa đơn")
    private String invoiceCode;
    @Schema(title = "Số lượng bán")
    private Long quantity;
    @Schema(title = "Số lượng trả")
    private Long returnQuantity;
    @Schema(title = "Giá bán")
    private String cost;
    @Schema(title = "Ngày bán")
    private String receiptDate;
    private Long sellerId;
    private Long unitId;
    private Long drugId;
    private Long warehouseId;

}
