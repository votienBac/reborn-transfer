package vn.reborn.core.http;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import okhttp3.*;
import org.springframework.stereotype.Component;
import vn.reborn.core.json.JsonObject;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static vn.reborn.core.template.RxTemplate.rxSchedulerNewThread;

@Log4j2
@Component
public class OkHttpService {
    private final OkHttpClient getClient;
    private static final MediaType TEXT = MediaType.parse("text/plain; charset=utf-8");
    public static final MediaType JSON = MediaType.get("application/json");
    public OkHttpService(OkHttpClient getClient) {
        this.getClient = getClient;
    }

    public <P, T> Single<Optional<P>> postJson(String url, T body, Class<P> rsClass) {
        return rxSchedulerNewThread(() -> {
            RequestBody requestBody = RequestBody.create(JsonObject.mapFrom(body).encode(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build();
            try (Response response = getClient.newCall(request).execute()) {
                return Optional.ofNullable(new JsonObject(response.body().string()).mapTo(rsClass));
            } catch (IOException e) {
                log.error("[POST REQUEST ERROR: ]", e);
                return Optional.empty();
            }
        });
    }
    public <P, T> Single<Optional<P>> postJson(String url, T body, Map<String, String> headers, Class<P> rsClass) {
        return rxSchedulerNewThread(() -> {
            RequestBody requestBody = RequestBody.create(JsonObject.mapFrom(body).encode(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .headers(Headers.of(headers))
                    .post(requestBody)
                    .build();
            try (Response response = getClient.newCall(request).execute()) {
                return Optional.ofNullable(new JsonObject(response.body().string()).mapTo(rsClass));
            } catch (IOException e) {
                log.error("[POST REQUEST ERROR: ]", e);
                return Optional.empty();
            }
        });
    }
    public <P, T> Single<Optional<P>> get(URL url, Map<String, String> headers, Class<P> rsClass) {
        return rxSchedulerNewThread(() -> {
            Request request = new Request.Builder()
                    .url(url)
                    .headers(Headers.of(headers))
                    .get()
                    .build();
            try (Response response = getClient.newCall(request).execute()) {
                return Optional.ofNullable(new JsonObject(response.body().string()).mapTo(rsClass));
            } catch (IOException e) {
                log.error("[GET REQUEST ERROR: ]", e);
                return Optional.empty();
            }
        });
    }


}
