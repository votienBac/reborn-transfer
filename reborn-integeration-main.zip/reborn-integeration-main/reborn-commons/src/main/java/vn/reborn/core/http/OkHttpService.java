package vn.reborn.core.http;

import io.reactivex.rxjava3.core.Single;
import lombok.extern.log4j.Log4j2;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.springframework.stereotype.Component;
import vn.reborn.core.json.JsonObject;

import java.io.IOException;
import java.util.Optional;

import static vn.reborn.core.template.RxTemplate.rxSchedulerNewThread;

@Log4j2
@Component
public class OkHttpService {
    private final OkHttpClient getClient;
    private static final MediaType TEXT = MediaType.parse("text/plain; charset=utf-8");
    public static final MediaType JSON = MediaType.get("application/json");
    public OkHttpService(OkHttpClient getClient) {
        this.getClient = getClient;
    }

    public <P, T> Single<Optional<P>> postJson(String url, T body, Class<P> rsClass) {
        return rxSchedulerNewThread(() -> {
            RequestBody requestBody = RequestBody.create(JsonObject.mapFrom(body).encode(), JSON);
            Request request = new Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build();
            try (Response response = getClient.newCall(request).execute()) {
                return Optional.ofNullable(new JsonObject(response.body().string()).mapTo(rsClass));
            } catch (IOException e) {
                log.error("[POST REQUEST ERROR: ]", e);
                return Optional.empty();
            }
        });
    }
}
