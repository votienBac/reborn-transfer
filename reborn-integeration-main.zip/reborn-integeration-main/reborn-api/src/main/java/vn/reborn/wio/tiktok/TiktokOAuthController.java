package vn.reborn.wio.tiktok;

import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.reborn.api.model.DfResponse;
import vn.reborn.data.request.tiktok.oauth.GetAccessTokenRQ;
import vn.reborn.data.response.tiktok.oauth.AccessTokenResponse;
import vn.reborn.service.oauth.ITiktokOAService;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "api/v1/tiktok-ads/oauth")
public class TiktokOAuthController {
    private final ITiktokOAService tiktokOAService;

    public TiktokOAuthController(ITiktokOAService tiktokOAService) {
        this.tiktokOAService = tiktokOAService;
    }


    @Operation(summary = "Lấy url OAuth")
    @ApiResponse(responseCode = "200", description = "Lấy url OAuth",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @GetMapping(value = "/get-url-authorize")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> oauthURL () {
        return tiktokOAService.getUrlAuthorize()
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Lấy access token")
    @ApiResponse(responseCode = "200", description = "Lấy access token",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = AccessTokenResponse.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/access-token")
    public @NonNull Single<ResponseEntity<DfResponse<AccessTokenResponse>>> getAccessToken (@RequestBody @Valid GetAccessTokenRQ request) {
        return tiktokOAService.getAccessToken(request)
                .map(DfResponse::okEntity);
    }

//    https://reborn.vn/test-login?
}
