package vn.reborn.wio.tiktok;

import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.reborn.api.model.DfResponse;
import vn.reborn.data.request.tiktok.campaign.CreateCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.SearchCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.UpdateCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.UpdateStatusCampaignRQ;
import vn.reborn.data.response.tiktok.campaign.CreateCampaignRS;
import vn.reborn.data.response.tiktok.campaign.UpdateStatusCampaignRS;
import vn.reborn.service.campaign.ICampaignService;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "api/v1/tiktok-ads/campaign")
public class ManageCampaignTiktokController {
    private final ICampaignService campaignService;

    public ManageCampaignTiktokController(ICampaignService campaignService) {
        this.campaignService = campaignService;
    }


    @Operation(summary = "Tạo mới campaign")
    @ApiResponse(responseCode = "200", description = "Tạo mới campaign",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = CreateCampaignRS.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/create")
    public @NonNull Single<ResponseEntity<DfResponse<CreateCampaignRS>>> create (@RequestBody @Valid CreateCampaignRQ request,
                                                                                 @RequestParam("access_token") String accessToken) {

        return campaignService.create(request, accessToken)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Chỉnh sửa campaign")
    @ApiResponse(responseCode = "200", description = "Chỉnh sửa campaign",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = CreateCampaignRS.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/update")
    public @NonNull Single<ResponseEntity<DfResponse<CreateCampaignRS>>> update (@RequestBody @Valid UpdateCampaignRQ request,
                                                                                     @RequestParam("access_token") String accessToken) {
        return campaignService.update(request, accessToken)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Lấy danh sách các campaign")
    @ApiResponse(responseCode = "200", description = "Lấy danh sách các campaign",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = CreateCampaignRS.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/search")
    public @NonNull Single<ResponseEntity<DfResponse<CreateCampaignRS>>> search (@RequestBody @Valid SearchCampaignRQ request,
                                                                                 @RequestParam("access_token") String accessToken) {
        return campaignService.search(request, accessToken)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Chỉnh sửa trạng thái campaign")
    @ApiResponse(responseCode = "200", description = "Chỉnh sửa trạng thái campaign",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = UpdateStatusCampaignRS.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/update-status")
    public @NonNull Single<ResponseEntity<DfResponse<UpdateStatusCampaignRS>>> updateStatus (@RequestBody @Valid UpdateStatusCampaignRQ request,
                                                                                 @RequestParam("access_token") String accessToken) {
        return campaignService.updateStatus(request, accessToken)
                .map(DfResponse::okEntity);
    }


}
