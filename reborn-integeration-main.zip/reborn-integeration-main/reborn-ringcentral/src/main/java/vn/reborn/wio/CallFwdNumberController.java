package vn.reborn.wio;

import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.reborn.api.model.DfResponse;
import vn.reborn.service.callfwd.ICallForwardingService;
import vn.reborn.service.calllog.ICallLogService;

import javax.validation.Valid;

//@RestController
@RequestMapping(value = "api/v1/ringcentral/call-fwd")
public class CallFwdNumberController {
    private final ICallForwardingService callFwdService;

    public CallFwdNumberController(ICallForwardingService callFwdService) {
        this.callFwdService = callFwdService;
    }
    @Operation(summary = "Tạo mới số fwd")
    @ApiResponse(responseCode = "200", description = "Tạo mới số fwd",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ForwardingNumberInfo.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/create")
    public @NonNull Single<ResponseEntity<DfResponse<ForwardingNumberInfo>>> create (@RequestBody @Valid CreateForwardingNumberRequest request) {
        return callFwdService.create(request)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Chỉnh sửa số fwd")
    @ApiResponse(responseCode = "200", description = "Chỉnh sửa số fwd",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ForwardingNumberInfo.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/update")
    public @NonNull Single<ResponseEntity<DfResponse<ForwardingNumberInfo>>> update (@RequestBody @Valid UpdateForwardingNumberRequest request) {
        return callFwdService.update(request)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Lấy danh sách các số forwarding")
    @ApiResponse(responseCode = "200", description = "Lấy danh sách các số forwarding",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = GetExtensionForwardingNumberListResponse.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/search")
    public @NonNull Single<ResponseEntity<DfResponse<GetExtensionForwardingNumberListResponse>>> search (@RequestBody @Valid ListForwardingNumbersParameters request) {
        return callFwdService.search(request)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Lấy thông tin chi tiết số fwd")
    @ApiResponse(responseCode = "200", description = "Lấy thông tin chi tiết fwd",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = ForwardingNumberResource.class))})
    @ApiResponse(responseCode = "400", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "401", description = "un authenticated", content = @Content)
    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content)
    @GetMapping(value = "/detail")
    public @NonNull Single<ResponseEntity<DfResponse<ForwardingNumberResource>>> detailCall (@RequestParam("fwd-number-id") String id) {
        return callFwdService.getByID(id)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Xóa record theo thời gian")
    @ApiResponse(responseCode = "200", description = "Xóa record theo thời gian",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/delete")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> deleteToDate (@RequestBody @Valid DeleteForwardingNumbersRequest request) {
        return callFwdService.delete(request)
                .map(DfResponse::okEntity);
    }

}
