package vn.reborn.wio;


import com.ringcentral.definitions.GetRingOutStatusResponse;
import com.ringcentral.definitions.MakeRingOutRequest;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.reborn.api.model.DfResponse;
import vn.reborn.service.ringout.IRingOutService;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "api/v1/ringcentral/ringout")
public class RingoutController {
    private final IRingOutService ringOutService;

    public RingoutController(IRingOutService ringOutService) {
        this.ringOutService = ringOutService;
    }
    @Operation(summary = "Tạo mới một cuộc gọi")
    @ApiResponse(responseCode = "200", description = "Tạo mới một cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = GetRingOutStatusResponse.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/create")
    public @NonNull Single<ResponseEntity<DfResponse<GetRingOutStatusResponse>>> makeCall (@RequestBody @Valid MakeRingOutRequest request) {
        return ringOutService.makeRingoutCall(request)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Lấy thông tin trạng thái cuộc gọi")
    @ApiResponse(responseCode = "200", description = "Lấy thông tin trạng thái cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = GetRingOutStatusResponse.class))})
    @ApiResponse(responseCode = "400", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "401", description = "un authenticated", content = @Content)
    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content)
    @GetMapping(value = "/status")
    public @NonNull Single<ResponseEntity<DfResponse<GetRingOutStatusResponse>>> getStatusCall (@RequestParam("ringout-id") String id) {
        return ringOutService.getRingoutCallStatus(id)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Hủy cuộc gọi")
    @ApiResponse(responseCode = "200", description = "Hủy cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @DeleteMapping(value = "/cancel")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> cancelCall (@RequestParam("ringout-id") String id) {
        return ringOutService.cancelRingoutCall(id)
                .map(DfResponse::okEntity);
    }

}
