package vn.reborn.wio;

import com.ringcentral.definitions.CallParty;
import com.ringcentral.definitions.CallRecording;
import com.ringcentral.definitions.CallRecordingUpdate;
import com.ringcentral.definitions.ForwardTarget;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import vn.reborn.api.model.DfResponse;
import vn.reborn.service.callcontrol.ICallControlService;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "api/v1/ringcentral/call-control")
public class CallControlController {
    private final ICallControlService callControlService;

    public CallControlController(ICallControlService callControlService) {
        this.callControlService = callControlService;
    }

    @Operation(summary = "Forward incoming call to another number")
    @ApiResponse(responseCode = "200", description = "Forward incoming call to another number",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = CallParty.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/forwarding")
    public @NonNull Single<ResponseEntity<DfResponse<CallParty>>> forwarding(@RequestParam("telephony-session-id") String telephonySessionId,
                                                                             @RequestParam("party-id") String partyId,
                                                                             @RequestBody @Valid ForwardTarget request) {
        return callControlService.forwardIncomingCall(telephonySessionId, partyId, request)
                .map(DfResponse::okEntity);
    }

    @Operation(summary = "Recording cuỘc gọi")
    @ApiResponse(responseCode = "200", description = "recording cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/recording")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> recording(@RequestParam("telephony-session-id") String telephonySessionId,
                                                                         @RequestParam("party-id") String partyId) {
        return callControlService.createRecording(telephonySessionId, partyId)
                .map(DfResponse::okEntity);
    }

    @Operation(summary = "Tiếp tục hoặc dừng Recording cuỘc gọi")
    @ApiResponse(responseCode = "200", description = "Tiếp tục hoặc dừng Recording cuỘc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = CallRecording.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/pause-resume")
    public @NonNull Single<ResponseEntity<DfResponse<CallRecording>>> recording(@RequestParam("telephony-session-id") String telephonySessionId,
                                                                                @RequestParam("party-id") String partyId,
                                                                                @RequestParam("recording-id") String recordingId,
                                                                                @RequestBody @Valid CallRecordingUpdate recordingUpdate) {
        return callControlService.pauseResumeRecording(telephonySessionId, partyId, recordingId, recordingUpdate)
                .map(DfResponse::okEntity);
    }

    @Operation(summary = "Từ choois cuỘc gọi")
    @ApiResponse(responseCode = "200", description = "Từ chối cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/reject")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> reject(@RequestParam("telephony-session-id") String telephonySessionId,
                                                                      @RequestParam("party-id") String partyId) {
        return callControlService.rejectCall(telephonySessionId, partyId)
                .map(DfResponse::okEntity);
    }

}
