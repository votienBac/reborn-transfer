package vn.reborn.service.callfwd;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.core.template.RxTemplate;

@Log4j2
@Service
public class CallForwardingServiceImpl implements ICallForwardingService {
    private final RestClient rc;

    public CallForwardingServiceImpl(RestClient rc) {
        this.rc = rc;
    }

    @SneakyThrows
    @Override
    public Single<ForwardingNumberInfo> create(CreateForwardingNumberRequest request){
        return RxTemplate.rxSchedulerIo(() ->{
            ForwardingNumberInfo response = rc.restapi().account().extension().forwardingNumber().post(request);
            return response;
        });
    }

    @SneakyThrows
    @Override
    public Single<ForwardingNumberInfo> update(UpdateForwardingNumberRequest request){
        return RxTemplate.rxSchedulerIo(() ->{
            ForwardingNumberInfo response = rc.restapi().account().extension().forwardingNumber().put(request);
            return response;
        });
    }

    @SneakyThrows
    @Override
    public Single<String> delete(DeleteForwardingNumbersRequest request){
        return RxTemplate.rxSchedulerIo(() ->{
            String response = rc.restapi().account().extension().forwardingNumber().deleteAll(request);
            return response;
        });
    }
    @SneakyThrows
    @Override
    public Single<GetExtensionForwardingNumberListResponse> search(ListForwardingNumbersParameters request){
        return RxTemplate.rxSchedulerIo(() ->{
            GetExtensionForwardingNumberListResponse response = rc.restapi().account().extension().forwardingNumber().list(request);
            return response;
        });
    }
    @SneakyThrows
    @Override
    public Single<ForwardingNumberResource> getByID(String id){
        return RxTemplate.rxSchedulerIo(() ->{
            ForwardingNumberResource response = rc.restapi().account().extension().forwardingNumber(id).get();
            return response;
        });
    }
}
