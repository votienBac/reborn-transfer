package vn.reborn.service.calllog;

import com.ringcentral.definitions.CallLogRecord;
import com.ringcentral.definitions.CallLogResponse;
import com.ringcentral.definitions.DeleteUserCallLogParameters;
import com.ringcentral.definitions.ReadUserCallLogParameters;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;

public interface ICallLogService {
    Single<CallLogResponse> getUserCallRecords(ReadUserCallLogParameters request);
    Single<CallLogRecord> getDetailCallLog(String callRecordId);
    Single<String> deleteCallLogToDate(DeleteUserCallLogParameters request);
    Single<String> deleteCallLogByID(String id);
}
