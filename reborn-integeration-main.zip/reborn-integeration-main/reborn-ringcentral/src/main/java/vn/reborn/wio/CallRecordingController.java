package vn.reborn.wio;

import com.ringcentral.definitions.GetCallRecordingResponse;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import vn.reborn.api.model.DfResponse;
import vn.reborn.service.callrecording.ICallRecordingService;

@RestController
@RequestMapping(value = "api/v1/ringcentral/call-recording")
public class CallRecordingController {
    private final ICallRecordingService callRecordingService;

    public CallRecordingController(ICallRecordingService callRecordingService) {
        this.callRecordingService = callRecordingService;
    }
    @Operation(summary = "Lấy recording cuộc gọi")
    @ApiResponse(responseCode = "200", description = "Lấy recording cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = GetCallRecordingResponse.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/get-recording")
    public @NonNull Single<ResponseEntity<DfResponse<GetCallRecordingResponse>>> getRecording (@RequestParam("recording-id") String recordingId) {
        return callRecordingService.getCallRecording(recordingId)
                .map(DfResponse::okEntity);
    }
//    @Operation(summary = "Lấy nội dung recording cuộc gọi")
//    @ApiResponse(responseCode = "200", description = "recording cuộc gọi",
//            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
//    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
//    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
//    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
//    @PostMapping(value = "/get-recording-content")
//    public @NonNull Single<ResponseEntity<DfResponse<String>>> getRecordingContent (@RequestParam("recording-id") String recordingId,
//                                                                              @RequestBody @Valid ReadCallRecordingContentParameters request) {
//        return callRecordingService.getCallRecordingContent(recordingId, request)
//                .map(DfResponse::okEntity);
//    }



}
