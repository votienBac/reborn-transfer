package vn.reborn.service.oauth;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.GetTokenRequest;
import com.ringcentral.definitions.TokenInfo;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.config.RCConfig;

import static vn.reborn.core.template.RxTemplate.*;

@Log4j2
@Service
public class OAuthServiceImpl implements IOAuthService{
    private final RCConfig rcConfig;
    private final RestClient restClient;

    public OAuthServiceImpl(RCConfig rcConfig, RestClient restClient) {
        this.rcConfig = rcConfig;
        this.restClient = restClient;
    }


    @SneakyThrows
    @Override
    public Single<String> generateOAuthRequest(){
        return rxSchedulerIo(() ->
                rcConfig.getServer()+"/restapi/oauth/authorize?response_type=code&client_id=" + rcConfig.getClientId() + "&redirect_uri="+ rcConfig.getRedirectUrl());
    }
    @SneakyThrows
    @Override
    public Single<TokenInfo> codeToAccessToken(String code){
        return rxSchedulerIo(() ->
                restClient.restapi().oauth().token().post(new GetTokenRequest().code(code)
                        .grant_type("authorization_code")
                        .redirect_uri(rcConfig.getRedirectUrl())));
    }
    @SneakyThrows
    @Override
    public Single<TokenInfo> refreshToken(String refreshToken){
        return rxSchedulerIo(() ->
                restClient.restapi().oauth().token().post(new GetTokenRequest().refresh_token(refreshToken)
                        .grant_type("refresh_token")));
    }
}
