package vn.reborn.service.ringout;

import com.ringcentral.definitions.GetRingOutStatusResponse;
import com.ringcentral.definitions.MakeRingOutRequest;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;

public interface IRingOutService {
    Single<GetRingOutStatusResponse> makeRingoutCall(MakeRingOutRequest request);

    @SneakyThrows
    Single<GetRingOutStatusResponse> getRingoutCallStatus(String ringoutId);

    @SneakyThrows
    Single<String> cancelRingoutCall(String ringoutId);
//    Single<RingOutStatusInfo>
}
