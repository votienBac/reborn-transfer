package vn.reborn.service.callcontrol;

import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;

public interface ICallControlService {
    @SneakyThrows
    Single<CallParty> forwardIncomingCall(String telephonySessionId, String partyId, ForwardTarget forwardTarget);

    @SneakyThrows
    Single<String> createRecording(String telephonySessionId, String partyId);

    @SneakyThrows
    Single<CallRecording> pauseResumeRecording(String telephonySessionId, String partyId, String recordingId, CallRecordingUpdate callRecordingUpdate);

    @SneakyThrows
    Single<String> rejectCall(String telephonySessionId, String partyId);


}
