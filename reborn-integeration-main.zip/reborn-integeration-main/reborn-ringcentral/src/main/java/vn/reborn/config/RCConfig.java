package vn.reborn.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties("ringcentral.credentials")
public class RCConfig {
    private String clientId;
    private String secretId;
    private Integer extensionId;
    private String redirectUrl;
    private String server;

}
