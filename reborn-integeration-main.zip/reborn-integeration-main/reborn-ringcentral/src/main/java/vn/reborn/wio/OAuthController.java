package vn.reborn.wio;

import com.ringcentral.definitions.GetCallRecordingResponse;
import com.ringcentral.definitions.TokenInfo;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.reborn.api.model.DfResponse;
import vn.reborn.service.oauth.IOAuthService;

@RestController
@RequestMapping(value = "api/v1/ringcentral/oauth")
public class OAuthController {
    private final IOAuthService ioAuthService;

    public OAuthController(IOAuthService ioAuthService) {
        this.ioAuthService = ioAuthService;
    }

    @Operation(summary = "Lấy url OAuth")
    @ApiResponse(responseCode = "200", description = "Lấy url OAuth",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @GetMapping(value = "/authorization")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> oauthURL () {
        return ioAuthService.generateOAuthRequest()
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Lấy url access token từ code")
    @ApiResponse(responseCode = "200", description = "Lấy url access token từ code",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = TokenInfo.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @GetMapping(value = "/code-to-accesstoken")
    public @NonNull Single<ResponseEntity<DfResponse<TokenInfo>>> codeToAccessToken (@RequestParam(name = "code") String code) {
        return ioAuthService.codeToAccessToken(code)
                .map(DfResponse::okEntity);
    }

//    https://reborn.vn/test-login?
}
