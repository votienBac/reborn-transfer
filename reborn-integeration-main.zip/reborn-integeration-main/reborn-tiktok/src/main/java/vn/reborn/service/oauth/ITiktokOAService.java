package vn.reborn.service.oauth;

import io.reactivex.rxjava3.core.Single;
import vn.reborn.data.request.tiktok.oauth.GetAccessTokenRQ;
import vn.reborn.data.response.tiktok.oauth.AccessTokenResponse;

public interface ITiktokOAService {
    Single<AccessTokenResponse> getAccessToken(GetAccessTokenRQ request);
}
