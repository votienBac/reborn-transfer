package vn.reborn.service.campaign;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.core.SingleSource;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.apache.hc.core5.net.URIBuilder;
import org.springframework.stereotype.Service;
import vn.reborn.core.exception.ApiException;
import vn.reborn.core.http.OkHttpService;
import vn.reborn.core.json.JsonObject;
import vn.reborn.data.request.tiktok.campaign.CreateCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.SearchCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.UpdateCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.UpdateStatusCampaignRQ;
import vn.reborn.data.response.tiktok.campaign.CreateCampaignRS;
import vn.reborn.data.response.tiktok.campaign.UpdateStatusCampaignRS;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static vn.reborn.data.constant.TiktokConstant.*;

@Log4j2
@Service
public class CampaignServiceImpl implements ICampaignService{
    private final OkHttpService okHttpService;
    private final ObjectMapper mapper = new ObjectMapper();

    public CampaignServiceImpl(OkHttpService okHttpService) {
        this.okHttpService = okHttpService;
    }
    @SneakyThrows
    @Override
    public Single<CreateCampaignRS> create(CreateCampaignRQ request, String accessToken){
        String url = BASE_URL + PATH_CREATE_CAMPAIGN;
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Token", accessToken);
        return okHttpService.postJson(url, request, headers, CreateCampaignRS.class)
                .flatMap(optRS ->optRS.<SingleSource<? extends CreateCampaignRS>>map(item -> Single.just(item))
                        .orElseGet(() -> Single.error(new ApiException("Create Campaign Fail"))));
    }
    @SneakyThrows
    @Override
    public Single<CreateCampaignRS> update(UpdateCampaignRQ request, String accessToken){
        String url = BASE_URL + PATH_UPDATE_CAMPAIGN;
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Token", accessToken);
        return okHttpService.postJson(url, request, headers, CreateCampaignRS.class)
                .flatMap(optRS ->optRS.<SingleSource<? extends CreateCampaignRS>>map(item -> Single.just(item))
                        .orElseGet(() -> Single.error(new ApiException("Update Campaign Fail"))));
    }
    @SneakyThrows
    @Override
    public Single<CreateCampaignRS> search(SearchCampaignRQ request, String accessToken){
        String urlBase = BASE_URL + PATH_GET_CAMPAIGN;
        Map<String, String> headers = new HashMap<>();
        String jsonStr = JsonObject.mapFrom(request).encode();
        URIBuilder ub = new URIBuilder(urlBase);
        Map< String, Object > map = mapper.readValue(jsonStr, Map.class);
        map.forEach((k, v) -> {
            try {
                ub.addParameter(k, v instanceof String ? (String) v : mapper.writeValueAsString(v));
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        });
        URL url = ub.build().toURL();

        headers.put("Access-Token", accessToken);
        return okHttpService.get(url, headers, CreateCampaignRS.class)
                .flatMap(optRS ->optRS.<SingleSource<? extends CreateCampaignRS>>map(Single::just)
                        .orElseGet(() -> Single.error(new ApiException("Search Campaign Fail"))));
    }
    @SneakyThrows
    @Override
    public Single<UpdateStatusCampaignRS> updateStatus(UpdateStatusCampaignRQ request, String accessToken){
        String url = BASE_URL + PATH_UPDATE_STATUS_CAMPAIGN;
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Token", accessToken);
        return okHttpService.postJson(url, request, headers, UpdateStatusCampaignRS.class)
                .flatMap(optRS ->optRS.<SingleSource<? extends UpdateStatusCampaignRS>>map(item -> Single.just(item))
                        .orElseGet(() -> Single.error(new ApiException("Update Status Campaign Fail"))));
    }
}
