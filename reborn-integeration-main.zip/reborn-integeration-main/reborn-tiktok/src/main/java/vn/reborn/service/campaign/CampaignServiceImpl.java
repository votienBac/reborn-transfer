package vn.reborn.service.campaign;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.core.http.OkHttpService;
import vn.reborn.data.constant.TiktokConstant;

import static vn.reborn.data.constant.TiktokConstant.BASE_URL;
import static vn.reborn.data.constant.TiktokConstant.PATH_CREATE_CAMPAIGN;

@Log4j2
@Service
public class CampaignServiceImpl implements ICampaignService{
    private final OkHttpService okHttpService;

    public CampaignServiceImpl(OkHttpService okHttpService) {
        this.okHttpService = okHttpService;
    }

    public Single<CreateCampaignRS> create(CreateCampaignRQ request, String accessToken){
        String url = BASE_URL + PATH_CREATE_CAMPAIGN;
        return okHttpService.postJson(url, request, )
    }
}
