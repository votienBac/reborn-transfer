package vn.reborn.service.campaign;

import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import vn.reborn.data.request.tiktok.campaign.CreateCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.SearchCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.UpdateCampaignRQ;
import vn.reborn.data.request.tiktok.campaign.UpdateStatusCampaignRQ;
import vn.reborn.data.response.tiktok.campaign.CreateCampaignRS;
import vn.reborn.data.response.tiktok.campaign.UpdateStatusCampaignRS;

public interface ICampaignService {
    @SneakyThrows
    Single<CreateCampaignRS> create(CreateCampaignRQ request, String accessToken);

    @SneakyThrows
    Single<CreateCampaignRS> update(UpdateCampaignRQ request, String accessToken);

    @SneakyThrows
    Single<CreateCampaignRS> search(SearchCampaignRQ request, String accessToken);

    @SneakyThrows
    Single<UpdateStatusCampaignRS> updateStatus(UpdateStatusCampaignRQ request, String accessToken);
}
