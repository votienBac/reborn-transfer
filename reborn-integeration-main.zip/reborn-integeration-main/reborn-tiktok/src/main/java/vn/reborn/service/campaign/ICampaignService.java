package vn.reborn.service.campaign;

public interface ICampaignService {
}
