package vn.reborn.repository;

import org.jooq.DSLContext;
import org.jooq.impl.TableRecordImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class CoreRepository<R extends TableRecordImpl<R>, P, ID> extends AbsRepository<R, P, ID> {
    @Autowired
    @Qualifier("rebornDslContext")
    protected DSLContext dslContext;

    @Override
    protected DSLContext getDslContext() {
        return dslContext;
    }
}
