package vn.reborn.api.config.authentication;

import vn.reborn.api.model.SimpleSecurityUser;

public interface IJwtParserService {
    SimpleSecurityUser parserUser(String token);
}
