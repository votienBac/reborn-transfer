package vn.reborn.api.config.security;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.stereotype.Service;

@Service
public class DefaultHttpSecurityResolver implements HttpSecurityResolver {
    @Override
    public void configure(HttpSecurity http) throws Exception {
        http.cors().and().csrf().disable()
                .exceptionHandling().and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
                .authorizeRequests()
                .antMatchers("/swagger-ui.html").permitAll()
                .antMatchers("/actuator/**").permitAll()
                .antMatchers("/api/v1/**").permitAll()
                .antMatchers("/api/admin/**").hasAnyRole("ADMIN")
                .anyRequest()
                .authenticated();
    }
}
