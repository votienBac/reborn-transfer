package vn.reborn.api.config.exception;

import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import vn.reborn.core.exception.ApiException;
import vn.reborn.core.exception.DBException;

import javax.validation.UnexpectedTypeException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.http.HttpStatus.*;

@Log4j2
@RestControllerAdvice
public class RestResponseEntityExceptionHandler {

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<Object> handleException(MissingServletRequestParameterException ex, WebRequest request) {
        String name = ex.getParameterName();
        return generateExceptionResponse(BAD_REQUEST.value(), "Missing " + name);
    }

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<Object> handlerAccessServiceException(ApiException ex, WebRequest request) {
        return generateExceptionResponse(ex.getCode(), ex.getMessage());
    }

    @ExceptionHandler(DBException.class)
    public ResponseEntity<Object> handlerDBException(DBException ex, WebRequest request) {
        ex.printStackTrace();
        return generateExceptionResponse(ex.getCode(), ex.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handlerException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return generateExceptionResponse(INTERNAL_SERVER_ERROR.value(), ex.getMessage());
    }

    @ExceptionHandler(UnexpectedTypeException.class)
    public ResponseEntity<Object> handlerUnexpectedTypeException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return generateExceptionResponse(INTERNAL_SERVER_ERROR.value(), INTERNAL_SERVER_ERROR.getReasonPhrase());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Object> handlerNotReadable(Exception ex, WebRequest request) {
        return generateExceptionResponse(NOT_ACCEPTABLE.value(), NOT_ACCEPTABLE.getReasonPhrase());
    }

    @ExceptionHandler(AuthenticationCredentialsNotFoundException.class)
    public ResponseEntity<Object> handlerAuthenticationException(Exception ex, WebRequest request) {
        return generateExceptionResponse(UNAUTHORIZED.value(), UNAUTHORIZED.getReasonPhrase());
    }

    @ExceptionHandler(UndeclaredThrowableException.class)
    public ResponseEntity<Object> handlerThrowableException(Exception ex, WebRequest request) {
        ex.printStackTrace();
        return generateExceptionResponse(INTERNAL_SERVER_ERROR.value(), INTERNAL_SERVER_ERROR.getReasonPhrase());
    }

    @ResponseStatus(BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors()
                .forEach(error -> {
                    String fieldName = ((FieldError) error).getField();
                    String errorMessage = error.getDefaultMessage();
                    errors.put(fieldName, errorMessage);
                });
        return errors;
    }

    private ResponseEntity<Object> generateExceptionResponse(Integer statusCode, String message) {
        if (statusCode == INTERNAL_SERVER_ERROR.value()) log.error(message);
        HttpStatus resolve = resolve(statusCode);
        if (resolve == null) resolve = BAD_REQUEST;
        return ResponseEntity.status(resolve)
                .body(new HashMap<String, Object>() {{
                    put("message", message);
                    put("code", statusCode);
                }});
    }
}
