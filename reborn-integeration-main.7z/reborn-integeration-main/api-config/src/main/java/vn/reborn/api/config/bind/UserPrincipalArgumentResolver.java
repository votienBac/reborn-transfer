package vn.reborn.api.config.bind;

import org.springframework.core.MethodParameter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import vn.reborn.core.model.UserPrincipal;
import vn.reborn.api.config.bind.annotation.UserPrincipalRequest;

import javax.servlet.http.HttpServletRequest;

import static vn.reborn.api.utils.SecurityUtils.getRoles;
import static vn.reborn.api.utils.SecurityUtils.userId;

public class UserPrincipalArgumentResolver implements HandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        return methodParameter.getParameterAnnotation(UserPrincipalRequest.class) != null;
    }

    @Override
    public UserPrincipal resolveArgument(
            MethodParameter methodParameter,
            ModelAndViewContainer modelAndViewContainer,
            NativeWebRequest nativeWebRequest,
            WebDataBinderFactory webDataBinderFactory) {

        HttpServletRequest request = (HttpServletRequest) nativeWebRequest.getNativeRequest();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipal userPrincipal = new UserPrincipal();
        if (request.getHeader("show_log") != null)
            userPrincipal.setShowLog(request.getHeader("show_log").equalsIgnoreCase("true"));
        if (request.getHeader("User-Agent") != null)
            userPrincipal.setAgentInfo(request.getHeader("User-Agent"));
        if (authentication != null)
            userPrincipal
                    .setUserId(userId(authentication))
                    .setRoles(getRoles(authentication));
        return userPrincipal;
    }
}
