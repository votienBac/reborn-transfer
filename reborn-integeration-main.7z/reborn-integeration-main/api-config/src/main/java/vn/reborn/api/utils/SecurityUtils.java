package vn.reborn.api.utils;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import vn.reborn.api.model.SimpleSecurityUser;
import vn.reborn.core.json.JsonObject;
import vn.reborn.data.constant.RoleConstant;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.math.NumberUtils.createLong;
import static org.apache.commons.lang3.math.NumberUtils.isDigits;

public class SecurityUtils {
    private SecurityUtils() {
    }

    public static List<String> getRoles(Authentication authentication) {
        if (authentication == null) return new ArrayList<>();
        return authentication.getAuthorities()
                .stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());
    }

    public static boolean isAdmin(Authentication authentication) {
        return getRoles(authentication)
                .stream()
                .anyMatch(role -> role.equals(RoleConstant.admin.name()));
    }

    public static Long userId(Authentication authentication) {
        if (authentication == null ||
                authentication.getAuthorities() == null ||
                !isDigits(authentication.getPrincipal().toString())) return null;
        return createLong(authentication.getPrincipal().toString());
    }

    public static Long drugStoreId(Authentication authentication) {
        if (authentication == null ||
                authentication.getCredentials() == null) return null;
        return JsonObject.mapFrom(authentication.getCredentials())
                .mapTo(SimpleSecurityUser.class)
                .getDrugStoreId();
    }

    public static String drugStoreType(Authentication authentication) {
        if (authentication == null ||
                authentication.getCredentials() == null) return null;
        return JsonObject.mapFrom(authentication.getCredentials())
                .mapTo(SimpleSecurityUser.class)
                .getType();
    }
}
