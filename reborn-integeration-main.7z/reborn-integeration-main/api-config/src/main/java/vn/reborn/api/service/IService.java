package vn.reborn.api.service;

import io.reactivex.rxjava3.core.Single;
import org.springframework.security.core.Authentication;
import vn.reborn.core.model.SearchRequest;
import vn.reborn.core.model.paging.Pageable;

import java.util.List;

public interface IService<Rq, Rs, I> {

    Single<Rs> findById(I id, Authentication authentication);

    Single<Rs> insert(Rq request, Authentication authentication);

    Single<Rs> update(I id, Rq request, Authentication authentication);

    Single<Boolean> delete(I id, Authentication authentication);

    Single<List<Rs>> list(Pageable pageable, Authentication authentication, boolean withExtraInfo);

    Single<List<Rs>> search(SearchRequest searchRequest, Authentication authentication);

    Single<Rs> addExtraInfo(Rs rs, Authentication authentication);

    Single<List<Rs>> addExtraInfo(List<Rs> rs, Authentication authentication);

    Single<List<Rs>> exportPage(SearchRequest searchRequest, Authentication authentication);

    Single<List<Rs>> exportSearch(SearchRequest searchRequest, Authentication authentication);

    Single<List<Rs>> exportAll(SearchRequest searchRequest, Authentication unitRepository);
}
