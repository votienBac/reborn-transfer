package vn.reborn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RebornMigrationApplication {
    public static void main(String[] args) {
        SpringApplication.run(RebornMigrationApplication.class, args);
    }
}
