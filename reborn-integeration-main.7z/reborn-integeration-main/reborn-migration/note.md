### Account là khách hàng (mapping bảng customer của mình)
### Contact là Người đại diện (giám đốc, trưởng phòng,... của 1 công ty), là đầu mối liên hệ của tổ chức, mapping với bảng contact của mình
### Deal là hợp đồng, mapping với bảng contract của mình
### 3 bảng trên đều có bảng định nghĩa thuộc tính động, tên tương ứng là customer_atttibute, contact_attribute, contract_attribute
Và có bảng lưu giá trị thuộc tính động tưng ứng là customer_extra_info, contact_extra_info, contract_extra_info


2023-10-01 10:34:00
2062-08-28 05:00:00