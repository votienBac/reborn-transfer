package vn.reborn.service.callcontrol;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.CallParty;
import com.ringcentral.definitions.ForwardTarget;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.core.template.RxTemplate;

@Log4j2
@Service
public class CallControlServiceImpl implements ICallControlService {
    private final RestClient rc;

    public CallControlServiceImpl(RestClient rc) {
        this.rc = rc;
    }

    @SneakyThrows
    @Override
    public Single<CallParty> forwardIncomingCall(String telephonySessionId, String partyId, ForwardTarget forwardTarget){
        return RxTemplate.rxSchedulerIo(() ->{
            CallParty response = rc.restapi().account().telephony().sessions(telephonySessionId).parties(partyId).forward().post(forwardTarget);
            return response;
        });
    }
}
