package vn.reborn.wio;

import com.oracle.svm.core.annotate.Delete;
import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.reborn.api.model.DfResponse;
import vn.reborn.service.calllog.ICallLogService;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "api/v1/ringcentral/call-log")
public class CallLogController {
    private final ICallLogService callLogService;

    public CallLogController(ICallLogService callLogService) {
        this.callLogService = callLogService;
    }

    @Operation(summary = "Lấy danh sách các cuộc gọi")
    @ApiResponse(responseCode = "200", description = "Lấy danh sách các cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = GetRingOutStatusResponse.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/search")
    public @NonNull Single<ResponseEntity<DfResponse<CallLogResponse>>> search (@RequestBody @Valid ReadUserCallLogParameters request) {
        return callLogService.getUserCallRecords(request)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Lấy thông tin chi tiết cuộc gọi")
    @ApiResponse(responseCode = "200", description = "Lấy thông tin chi tiết cuộc gọi",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = CallLogRecord.class))})
    @ApiResponse(responseCode = "400", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "401", description = "un authenticated", content = @Content)
    @ApiResponse(responseCode = "403", description = "Forbidden", content = @Content)
    @GetMapping(value = "/detail")
    public @NonNull Single<ResponseEntity<DfResponse<CallLogRecord>>> detailCall (@RequestParam("record-id") String id) {
        return callLogService.getDetailCallLog(id)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Xóa record theo thời gian")
    @ApiResponse(responseCode = "200", description = "Xóa record theo thời gian",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @PostMapping(value = "/delete-date-to")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> deleteToDate (@RequestBody @Valid DeleteUserCallLogParameters request) {
        return callLogService.deleteCallLogToDate(request)
                .map(DfResponse::okEntity);
    }
    @Operation(summary = "Xóa record theo id")
    @ApiResponse(responseCode = "200", description = "Xóa record theo id",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})
    @ApiResponse(responseCode = "404", description = "bad-request", content = @Content)
    @ApiResponse(responseCode = "400", description = "Thông tin gửi lên đã tồn tại", content = @Content)
    @ApiResponse(responseCode = "422", description = "Thông tin gửi về không đúng hoặc thiếu", content = @Content)
    @DeleteMapping(value = "/delete")
    public @NonNull Single<ResponseEntity<DfResponse<String>>> deleteByID (@RequestParam("record-id") String id) {
        return callLogService.deleteCallLogByID(id)
                .map(DfResponse::okEntity);
    }
}
