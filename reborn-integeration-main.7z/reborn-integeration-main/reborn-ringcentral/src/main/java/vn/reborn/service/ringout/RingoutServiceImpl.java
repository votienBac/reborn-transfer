package vn.reborn.service.ringout;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.CreateForwardingNumberRequest;
import com.ringcentral.definitions.GetRingOutStatusResponse;
import com.ringcentral.definitions.MakeRingOutRequest;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.core.template.RxTemplate;
import vn.reborn.utils.JSONUtils;

@Log4j2
@Service
public class RingoutServiceImpl implements IRingOutService{
    private final RestClient rc;
    public RingoutServiceImpl(RestClient rc) {
        this.rc = rc;
    }
    @SneakyThrows
    @Override
    public Single<GetRingOutStatusResponse> makeRingoutCall(MakeRingOutRequest request) {
        return RxTemplate.rxSchedulerIo(() ->{
            log.info("Make ringout call with request: "+ JSONUtils.convertToJSON(request));
            GetRingOutStatusResponse response = rc.restapi().account().extension().ringOut().post(request);
            log.info("Response ringout call "+ JSONUtils.convertToJSON(response));
            return response;
        });
    }
    @SneakyThrows
    @Override
    public Single<GetRingOutStatusResponse> getRingoutCallStatus(String ringoutId){
        return RxTemplate.rxSchedulerIo(() ->{
            GetRingOutStatusResponse response = rc.restapi().account().extension().ringOut(ringoutId).get();
            return response;
        });
    }

    @SneakyThrows
    @Override
    public Single<String> cancelRingoutCall(String ringoutId){
        return RxTemplate.rxSchedulerIo(() ->{
            String response = rc.restapi().account().extension().ringOut(ringoutId).delete();
            log.info("Response ringout call "+ JSONUtils.convertToJSON(response));
            return response;
        });
    }
}
