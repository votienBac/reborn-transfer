package vn.reborn.service.calllog;

public interface ICallLogService {
}
