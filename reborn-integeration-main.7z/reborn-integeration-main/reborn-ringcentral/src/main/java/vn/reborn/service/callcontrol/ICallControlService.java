package vn.reborn.service.callcontrol;

public interface ICallControlService {
}
