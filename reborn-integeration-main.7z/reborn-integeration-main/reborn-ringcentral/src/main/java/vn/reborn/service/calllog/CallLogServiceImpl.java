package vn.reborn.service.calllog;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.CallLogRecord;
import com.ringcentral.definitions.GetRingOutStatusResponse;
import com.ringcentral.definitions.ReadUserCallLogParameters;
import com.ringcentral.definitions.ReadUserCallRecordParameters;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.core.template.RxTemplate;
import vn.reborn.utils.JSONUtils;

@Log4j2
@Service
public class CallLogServiceImpl {
    private final RestClient rc;
    public CallLogServiceImpl(RestClient rc) {
        this.rc = rc;
    }
    Single<List<>> getUserCallRecords(CallLogRecord record){
        return RxTemplate.rxSchedulerIo(() ->{
            GetRingOutStatusResponse response = rc.restapi().account().extension().callLog().list(new ReadUserCallLogParameters());

            return response;
        });
    }
}
