package vn.reborn.service.calllog;

import com.ringcentral.RestClient;
import com.ringcentral.definitions.*;
import io.reactivex.rxjava3.core.Single;
import lombok.SneakyThrows;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import vn.reborn.core.template.RxTemplate;

@Log4j2
@Service
public class CallLogServiceImpl implements ICallLogService{
    private final RestClient rc;
    public CallLogServiceImpl(RestClient rc) {
        this.rc = rc;
    }
    @SneakyThrows
    @Override
    public Single<CallLogResponse> getUserCallRecords(ReadUserCallLogParameters request){
        return RxTemplate.rxSchedulerIo(() ->{
            CallLogResponse response = rc.restapi().account().extension().callLog().list(request);
            return response;
        });
    }
    @SneakyThrows
    @Override
    public Single<CallLogRecord> getDetailCallLog(String callRecordId) {
        return RxTemplate.rxSchedulerIo(() ->{
            CallLogRecord response = rc.restapi().account().extension().callLog(callRecordId).get();
            return response;
        });
    }
    @SneakyThrows
    @Override
    public Single<String> deleteCallLogToDate(DeleteUserCallLogParameters request) {
        return RxTemplate.rxSchedulerIo(() ->{
            String response = rc.restapi().account().extension().callLog().delete(request);
            return response;
        });
    }
    @SneakyThrows
    @Override
    public Single<String> deleteCallLogByID(String id) {
        return RxTemplate.rxSchedulerIo(() ->{
            String response = rc.restapi().account().extension().callLog(id).delete();
            return response;
        });
    }
}
