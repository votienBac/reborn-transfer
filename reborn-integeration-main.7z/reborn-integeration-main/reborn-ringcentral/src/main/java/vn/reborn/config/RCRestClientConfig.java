package vn.reborn.config;

import com.ringcentral.RestClient;
import lombok.SneakyThrows;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RCRestClientConfig {
    private RCConfig rcConfig;

    public RCRestClientConfig(RCConfig rcConfig) {
        this.rcConfig = rcConfig;
    }
    @SneakyThrows
    @Bean
    public RestClient client(){
        RestClient rc =  new RestClient(rcConfig.getClientId(), rcConfig.getSecretId(), rcConfig.getServer());
        rc.authorize(rcConfig.getAccessToken());
        return rc;
    }
}
