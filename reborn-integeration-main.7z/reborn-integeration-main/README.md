# reborn-integeration
Tích hợp các hệ thống ngoài vào CRM
