package vn.reborn.data.enums;

import lombok.Getter;


@Getter
public enum CodeTypeEnum {
    TL("TL", null),
    DRUG("DRUG", null),
    SP("SP", null),
    KP("KP", null),
    PT("PT", "receive"),
    PC("PC", "payment"),
    PN("PN", null),
    HD("HD", null),
    HDT("HDT", null),
    PTH("PTH", null),
    XK("XK", null),
    NK("NK", null),
    DDH("DDH", null);

    private String name;
    private String type;

    CodeTypeEnum(String name, String type) {
        this.name = name;
        this.type = type;
    }
}
