package vn.reborn.data.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.experimental.Accessors;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
@Accessors(chain = true)
public class AmountDailyDTO {
    @JsonIgnore
    private LocalDateTime cashDate;
    private String date;
    private Long amount;

    public String getDateTime() {
        return cashDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
}
