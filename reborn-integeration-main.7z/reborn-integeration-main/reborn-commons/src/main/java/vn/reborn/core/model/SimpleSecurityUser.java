package vn.reborn.core.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;


@Data
@Accessors(chain = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SimpleSecurityUser {
    private String id;
    private String username;
    private String password;
    private String accessToken;
    private String adminId;
    private List<String> roles;
}