package vn.reborn.repository;

import io.reactivex.rxjava3.core.Single;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface IMysqlBaseRepository<P, ID> {
    Single<Integer> insert(P pojo);

    ID insertBlocking(P pojo);

    Single<List<P>> getAllByIds(List<ID> ids);

    Single<Map<ID, P>> getMap(Collection<ID> ids);
}
