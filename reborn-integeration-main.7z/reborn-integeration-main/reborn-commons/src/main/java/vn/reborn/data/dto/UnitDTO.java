package vn.reborn.data.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class UnitDTO {
    @Schema(description = "warehouse_id")
    private Long id;
    private Long drugStoreId;
    private Long drugId;
    @Schema(description = "Hệ số quy đổi")
    private Integer exchange;
    @Schema(description = "Giá quy đổi")
    private Long currentCost;
    private Long mainCost;
    @Schema(description = "id của đơn vị quy đổi")
    private Long unitId;
    @Schema(description = "số coin quy đổi")
    private Long numCoin;
    private String unitName;
    private Long ratio;
    private String isBasic;
    private Long quantity;
}
