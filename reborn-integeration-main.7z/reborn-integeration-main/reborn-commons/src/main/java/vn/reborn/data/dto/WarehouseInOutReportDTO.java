package vn.reborn.data.dto;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class WarehouseInOutReportDTO {
    private Long warehouseId;
    private Long drugId;
    private String number;
    private Long unitId;
    private String unitName;
    private Long quantity;
    private Long mainCost;
    private Long currentCost;
    private String expiryDate;
}
