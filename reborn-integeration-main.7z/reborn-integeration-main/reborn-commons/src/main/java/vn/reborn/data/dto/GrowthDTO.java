package vn.reborn.data.dto;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class GrowthDTO {
    private Double growth;
    private Long currentValue;
    private Long periodValue;
    private String fromDate;
    private String toDate;
    private String periodFromDate;
    private String periodToDate;
}
