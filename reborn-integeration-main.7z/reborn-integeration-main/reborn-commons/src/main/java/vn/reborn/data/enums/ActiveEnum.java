package vn.reborn.data.enums;


import lombok.Getter;


@Getter
public enum ActiveEnum {

    yes("yes", true),

    no("no", false);

    private final String literal;
    private final boolean value;

    ActiveEnum(String literal, boolean value) {
        this.literal = literal;
        this.value = value;
    }
    public Boolean value() {
        return value;
    }


}
