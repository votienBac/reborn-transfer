package vn.reborn.repository;

import org.jooq.Condition;

import java.util.List;

public interface IEsRepository<Pojo> {
    List<Pojo> getWithOffsetLimit(int offset, int limit);

    List<Pojo> getWithOffsetLimit(int offset, int limit, Condition condition);

    Long countAll();
}
