package vn.reborn.data.constant;

public class GenericFieldConstant {
    public static final String ID = "id";
    public static final String _ID = "_id";
    public static final String TAG = "tag";
    public static final String COUNT = "count";
    public static final String UNIT_NAME = "unit_name";
    public static final String TITLE = "title";
    public static final String TYPE = "type";
    public static final String EXTRA_NAME = "extra_name";
    public static final String DRUG_STORE_ID = "drug_store_id";
    public static final String ACTIVE = "active";
    public static final String ALPHABET_GROUP = "alphabet_group";
    public static final String DRUG_CODE = "drug_code";
    public static final String IS_INVENTORY = "is_inventory";

    public static final String NAME = "name";
    public static final String BARCODE = "barcode";
    public static final String DRUG_CATEGORY_ID = "drug_category_id";
    public static final String DRUG_GROUP_ID = "drug_group_id";

    public static final String NAME_SEARCH_FIELD = "name_search_field";
    public static final String SUBSTANCES_SEARCH_FIELD = "substances_search_field";
    public static final String COMPANY_SEARCH_FIELD = "company_search_field";
    public static final String GENERAL_SEARCH_FIELD = "general_search_field";

}
