package vn.reborn.data.enums;


import lombok.Getter;


@Getter
public enum WarehouseMasterIsBasic {

    yes("yes"),

    no("no");

    private final String literal;

    WarehouseMasterIsBasic(String literal) {
        this.literal = literal;
    }

}
