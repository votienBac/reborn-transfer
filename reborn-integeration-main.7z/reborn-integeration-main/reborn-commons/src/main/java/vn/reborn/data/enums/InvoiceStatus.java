package vn.reborn.data.enums;


import lombok.Getter;

@Getter
public enum InvoiceStatus {

    temp("temp"),
    done("done"),

    cancel("cancel"),

    pending("pending");

    private final String literal;

    InvoiceStatus(String literal) {
        this.literal = literal;
    }

}
