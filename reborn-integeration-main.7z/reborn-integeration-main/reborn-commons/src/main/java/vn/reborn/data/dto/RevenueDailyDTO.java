package vn.reborn.data.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class RevenueDailyDTO {
    @Schema(title = "Ngày nhận")
    public LocalDateTime receiptDate;
    @Schema(title = "Thu tiền mặt")
    public Long cashAmount;
    @Schema(title = "Thu qua Chuyển khoản/Ví/Thẻ")
    public Long bankAmount;
    @Schema(title = "Doanh thu bán trực tiếp")
    public Long directAmount;
    @Schema(title = "Doanh thu bán Online/COD")
    public Long onlineAmount;
    @Schema(title = "Tổng VAT")
    public Long vatAmount;
    @Schema(title = "Doanh thu trước giảm giá")
    public Long amount;
    @Schema(title = "Giảm giá")
    public Long discount;
    @Schema(title = "Doanh thu chưa công nợ")
    public Long total;
    @Schema(title = "Công nợ")
    public Long debt;
    @Schema(title = "Tổng doanh thu")
    public Long sumAmount;

    public Long getSumAmount() {
        return total + debt;
    }

    public String getReceiptDate() {
        if (receiptDate == null) return null;
        return receiptDate.toLocalDate().toString();
    }
}
