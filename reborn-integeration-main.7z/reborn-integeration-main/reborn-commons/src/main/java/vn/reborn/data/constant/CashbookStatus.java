package vn.reborn.data.constant;

public enum CashbookStatus {
    done, cancel
}
