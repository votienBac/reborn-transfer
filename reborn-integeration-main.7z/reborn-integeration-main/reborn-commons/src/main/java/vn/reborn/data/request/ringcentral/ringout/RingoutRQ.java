package vn.reborn.data.request.ringcentral.ringout;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class RingoutRQ {
}
