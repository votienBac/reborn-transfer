package vn.reborn.data.constant;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum ExportType {
    ALL("all"),
    CURRENT_PAGE("current_page"),
    CURRENT_SEARCH("current_search");

    private final String type;

    ExportType(String type) {
        this.type = type;
    }

    public static ExportType from(String value) {
        return Arrays.stream(values())
                .filter(exportType -> exportType.getType().equalsIgnoreCase(value))
                .findFirst()
                .orElse(null);
    }
}
