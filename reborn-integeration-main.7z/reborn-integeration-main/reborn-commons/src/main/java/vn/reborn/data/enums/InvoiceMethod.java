package vn.reborn.data.enums;

import lombok.Getter;

@Getter
public enum InvoiceMethod {

    direct("direct"),

    online("online");

    private final String literal;

    private InvoiceMethod(String literal) {
        this.literal = literal;
    }

}
