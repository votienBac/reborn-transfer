package vn.reborn.repository;

import org.jooq.Condition;
import org.jooq.DSLContext;
import vn.reborn.repository.utils.UpdateField;

import java.util.Collection;
import java.util.List;

public interface IBlockingRepository<P, ID> {
    void insertBlockingOnDuplicateUpdate(Collection<P> pojos, DSLContext context);

    void insertBlockingOnDuplicateIgnore(Collection<P> pojos, DSLContext context);

    List<P> getActiveBlocking();

    P insertBlocking(P pojo, DSLContext dslContext);

    void insertOnDuplicateKeyUpdateBlocking(P pojo, DSLContext context);

    void insertBlocking(Collection<P> pojos, DSLContext context);

    void updateBlocking(ID id, P pojo, DSLContext context);

    Integer updateBlocking(ID id, UpdateField updateField, DSLContext context);

    Integer updateBlockingByCondition(Condition condition, UpdateField updateField, DSLContext context);

}
