package vn.reborn.data.constant;

public enum RoleConstant {
    admin
}
