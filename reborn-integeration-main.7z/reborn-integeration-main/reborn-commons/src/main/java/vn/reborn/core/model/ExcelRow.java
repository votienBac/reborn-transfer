package vn.reborn.core.model;

import lombok.Data;

@Data
public abstract class ExcelRow {
    private Integer row;

}
