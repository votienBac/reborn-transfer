package vn.reborn.data.mapper;

import org.mapstruct.IterableMapping;
import org.mapstruct.Named;

import java.time.LocalDateTime;
import java.util.List;

import static vn.reborn.utils.TimeUtil.parserToLocalDateTime;

public abstract class AbsMapper<R, P> {

    @Named("toResponse")
    public abstract R toResponse(P p);

    @IterableMapping(qualifiedByName = "toResponse")
    public abstract List<R> toResponses(List<P> ps);

    protected LocalDateTime mapToLocalDateTime(String input) {
        return parserToLocalDateTime(input);
    }
}
