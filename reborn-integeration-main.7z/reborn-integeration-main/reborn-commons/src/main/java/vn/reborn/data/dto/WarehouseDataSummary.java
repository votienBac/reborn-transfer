package vn.reborn.data.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;

@Data
@Accessors(chain = true)
public class WarehouseDataSummary {
    private BigDecimal totalBuy;
    private BigDecimal totalSell;
}
