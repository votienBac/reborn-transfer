package vn.reborn.core.model;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.List;

@Data
@Accessors(chain = true)
public class UserPrincipal {
    private String ip;
    private Long userId = 0L;
    private String clientId;
    private String agentInfo;
    private List<String> roles;
    private Boolean showLog;
    private Object clientInfo;
}
