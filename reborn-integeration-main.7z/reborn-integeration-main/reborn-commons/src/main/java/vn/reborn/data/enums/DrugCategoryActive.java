package vn.reborn.data.enums;


import lombok.Getter;

@Getter
public enum DrugCategoryActive {

    yes("yes"),

    no("no");

    private final String literal;

    DrugCategoryActive(String literal) {
        this.literal = literal;
    }

}
