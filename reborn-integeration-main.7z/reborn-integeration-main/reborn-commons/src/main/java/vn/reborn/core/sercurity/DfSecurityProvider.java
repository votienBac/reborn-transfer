package vn.reborn.core.sercurity;

import java.util.List;

public interface DfSecurityProvider {
    List<String> getRoles();

    boolean isAdmin();

    Long loggedUserId();

    boolean showLogInfo();

    Object getAuthentication();

}
