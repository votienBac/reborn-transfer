package vn.reborn.utils;

import java.util.UUID;

public class GenIDUtils {
    private static final int SHORT_ID_LENGTH = 8;

    public static String genUUID() {
        return UUID.randomUUID().toString();
    }

    public static String genShortUUID() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, SHORT_ID_LENGTH);
    }

    public static Integer genShortUUIDInt() {
        return Integer.parseInt(genShortUUID());
    }

    public static String initUserStatisticYearId(String userId, Integer year) {
        return userId + "_" + year;
    }

    public static void main(String[] args) {
        UUID uuid = UUID.randomUUID();
        long timestamp = uuid.timestamp();
        String s = genShortUUID();
    }
}
