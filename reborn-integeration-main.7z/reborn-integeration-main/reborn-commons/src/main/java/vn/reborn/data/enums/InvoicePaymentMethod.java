package vn.reborn.data.enums;


import lombok.Getter;

@Getter
public enum InvoicePaymentMethod {

    cash("cash"),

    banking("banking"),

    card("card"),

    momo("momo"),

    vnpay("vnpay"),

    other("other"),

    debt("debt");

    private final String literal;

    InvoicePaymentMethod(String literal) {
        this.literal = literal;
    }

}
