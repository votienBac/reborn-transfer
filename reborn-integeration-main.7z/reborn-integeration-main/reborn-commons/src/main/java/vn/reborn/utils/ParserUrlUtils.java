package vn.reborn.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.hc.core5.http.NameValuePair;
import org.apache.hc.core5.net.URLEncodedUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.compile;

public class ParserUrlUtils {
    private static Logger logger = LoggerFactory.getLogger(ParserUrlUtils.class);
    private static Pattern postPattern = compile("^\\/(?:post|question|blog|page\\/.*?/post|page\\/.*?/question|page\\/.*?/blog)\\/.*?(\\d+)$");

    public static String parserGetPostId(String url) {
        String absoluteUrl = getAbsoluteUrl(url, false);
        if (StringUtils.isEmpty(absoluteUrl)) return null;
        Matcher matcher = postPattern.matcher(absoluteUrl);
        if (matcher.find()) {
            if (matcher.groupCount() > 0) {
                return matcher.group(1);
            }
        }
        return null;
    }

    public static String getAbsoluteUrl(String urlStr, boolean containParams) {
        if (urlStr == null || urlStr.equals("")) return null;
        try {
            URL url = new URL(urlStr);
            String absolutePath = url.getPath();
            String query = url.getQuery();
            if (containParams && query != null) absolutePath = absolutePath + "?" + query;
            if (absolutePath.equals("")) return "/";
            return absolutePath;
        } catch (Exception e) {
            logger.error("Malformed url exception {}", urlStr, e);
        }
        return null;
    }

    public static String getHostname(String urlStr) {
        if (urlStr == null || urlStr.equals("")) return null;
        try {
            URL url = new URL(urlStr);
            return url.getHost();
        } catch (Exception e) {
            logger.error("Malformed url exception {}", urlStr, e);
        }
        return null;
    }

    public static Map<String, String> extractUrlParams(String urlStr) {
        Map<String, String> paramsMap = new HashMap<>();
        if (urlStr == null || urlStr.equals("")) return paramsMap;
        try {
            List<NameValuePair> params = URLEncodedUtils.parse(urlStr, StandardCharsets.UTF_8);
            params.forEach(nameValuePair -> {
                String name = nameValuePair.getName();
                String value = nameValuePair.getValue();
                if (name != null && name.contains("?")) name = name.split("\\?")[1];
                if (value != null && value.contains("#")) value = value.split("#")[0];
                if (name != null && value != null) paramsMap.put(name, value);
            });
            return paramsMap;
        } catch (Exception e) {
            logger.warn("Malformed url exception {}", urlStr, e);
        }
        return paramsMap;
    }

    public static String getParam(String urlStr, String paramName) {
        return extractUrlParams(urlStr).getOrDefault(paramName, null);
    }

    public static void main(String[] args) {
        String url = "https://www.noron.vn/post/work-hard-hay-work-smart-quan-trong-hon-lloscim7w1v?view_cid=78982014412833886#78982014412833885&nrclid=99963480504796403";
        Map<String, String> stringStringMap = extractUrlParams(url);
        String nrclid = getParam(url, "nrclid");
        System.out.println(getHostname(url));
        System.out.println(getHostname("https://noron.vn/post"));
        System.out.println();
    }
}
