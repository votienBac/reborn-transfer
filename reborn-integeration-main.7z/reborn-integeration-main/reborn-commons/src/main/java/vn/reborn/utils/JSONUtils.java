package vn.reborn.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.util.stream.Collectors.groupingBy;

public class JSONUtils {
    private static final Logger logger = LoggerFactory.getLogger(JSONUtils.class);

    private static ObjectMapper objectMapper;
    @SneakyThrows
    public static <T> String convertToJSON(T object){
        return objectMapper.writeValueAsString(object);
    }


}
