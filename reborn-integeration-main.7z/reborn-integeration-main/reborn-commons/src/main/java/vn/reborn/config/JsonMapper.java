package vn.reborn.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.jooq.JSON;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import vn.reborn.config.jackson.JSONDeserializer;
import vn.reborn.config.jackson.JSONSerializer;

import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.PropertyNamingStrategies.SNAKE_CASE;

@Configuration
public class JsonMapper {
    private static ObjectMapper objectMapper;

    public static ObjectMapper getObjectMapper() {
        if (objectMapper == null) new JsonMapper().resetJsonConfig();
        return objectMapper;
    }

    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        if (objectMapper == null) new JsonMapper().resetJsonConfig();
        return objectMapper;
    }
    public void resetJsonConfig() {
        objectMapper = new ObjectMapper();
        objectMapper
                .registerModule(new JavaTimeModule())
                .registerModule(JSONModule())
                .setPropertyNamingStrategy(SNAKE_CASE)
                .configure(FAIL_ON_UNKNOWN_PROPERTIES, false);
//        objectMapper.registerModule(JSONModule());
    }

    public static SimpleModule JSONModule() {
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addDeserializer(JSON.class, new JSONDeserializer());
        simpleModule.addSerializer(JSON.class, new JSONSerializer());
        return simpleModule;
    }
}