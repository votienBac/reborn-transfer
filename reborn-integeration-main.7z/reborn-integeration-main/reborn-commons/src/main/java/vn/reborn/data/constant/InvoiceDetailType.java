package vn.reborn.data.constant;

import lombok.Getter;

@Getter
public enum InvoiceDetailType {
    RETAIL("retail", "Bán lẽ"),
    COMBO("combo", "Bán combo"),
    PRESCRIPTION("prescription", "Đơn thuốc");

    private final String type;

    InvoiceDetailType(String type, String description) {
        this.type = type;
    }
}
