package vn.reborn.data.constant;

import lombok.Getter;

@Getter
public enum DrugStoreType {
    GDP("GDP"), GPP("GPP");
    private String name;

    DrugStoreType(String name) {
        this.name = name;
    }
}
