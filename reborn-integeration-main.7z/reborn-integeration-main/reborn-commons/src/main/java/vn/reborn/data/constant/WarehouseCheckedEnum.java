package vn.reborn.data.constant;

import lombok.Getter;

@Getter
public enum WarehouseCheckedEnum {
    MASTER_DATA(true),
    STOCK(false);

    private final boolean isCheck;

    WarehouseCheckedEnum(boolean isCheck) {
        this.isCheck = isCheck;
    }
}
