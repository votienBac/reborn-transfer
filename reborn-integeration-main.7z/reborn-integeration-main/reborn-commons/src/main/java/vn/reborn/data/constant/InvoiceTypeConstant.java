package vn.reborn.data.constant;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum InvoiceTypeConstant {
    IV1("IV1", "Hoa don ban hang", "{% if is_debt == true %}" +
            "Phiếu thu công nợ cho hóa đơn bán hàng mã {{invoice_code}}" +
            "{% else %}" +
            "Phiếu thu cho hóa đơn bán hàng mã {{invoice_code}}" +
            "{% endif %}", "AC1"),
    IV2("IV2", "Hoa don nhap hang",
            "Phiếu chi cho hóa đơn nhập hàng mã {{invoice_code}}", "AC2"),
    IV3("IV3", "Khach hang mua roi tra lai thuoc",
            "Phiếu chi cho hóa đơn khách trả hàng mã {{invoice_code}}", "AC2"),
    IV4("IV4", "Tra hang nha cung cap", "Phiếu thu cho hóa đơn trả hàng NCC mã {{invoice_code}}", "AC2"),
    IV5("IV5", "Hoa don khac", null, "AC2"),
    IV7("IV7", "Hoa don nhap ton",
            "Phiếu chi cho hóa đơn nhập tồn mã {{invoice_code}}", "AC2"),
    IV8("IV8", "Hoa don xuat huy", null, "AC8"),
    NOT_FOUND(null, null, null, null);

    private String type;
    private String description;
    private String cashbookReason;
    private String action;

    InvoiceTypeConstant(String type, String description,
                        String cashbookReason,
                        String action) {
        this.type = type;
        this.description = description;
        this.cashbookReason = cashbookReason;
        this.action = action;
    }

    public static InvoiceTypeConstant form(String type) {
        return Arrays.stream(values())
                .filter(invoiceTypeConstant -> invoiceTypeConstant.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElse(NOT_FOUND);
    }
}
