package com.ringcentral;

public enum ContentType {
    JSON, FORM, MULTIPART
}
