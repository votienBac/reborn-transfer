package com.ringcentral.definitions;


public class CaiAsyncApiResponse {
    /**
     *
     */
    public String jobId;

    public CaiAsyncApiResponse jobId(String jobId) {
        this.jobId = jobId;
        return this;
    }
}
