package com.ringcentral.definitions;


public class BulkAddDevicesItemEmergencyLocation {
    /**
     * Emergency location ID
     */
    public String id;

    public BulkAddDevicesItemEmergencyLocation id(String id) {
        this.id = id;
        return this;
    }
}
