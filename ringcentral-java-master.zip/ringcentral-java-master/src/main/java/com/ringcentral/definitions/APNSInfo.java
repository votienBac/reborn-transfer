package com.ringcentral.definitions;


/**
 * APNS (Apple Push Notification Service) information
 */
public class APNSInfo {
    /**
     *
     */
    public APSInfo aps;

    public APNSInfo aps(APSInfo aps) {
        this.aps = aps;
        return this;
    }
}
