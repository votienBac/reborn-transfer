package com.ringcentral.definitions;


public class CallPartyFlip {
    /**
     * Call flip id
     */
    public String callFlipId;

    public CallPartyFlip callFlipId(String callFlipId) {
        this.callFlipId = callFlipId;
        return this;
    }
}
