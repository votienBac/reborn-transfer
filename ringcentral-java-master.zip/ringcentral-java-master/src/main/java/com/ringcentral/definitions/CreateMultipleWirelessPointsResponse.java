package com.ringcentral.definitions;


public class CreateMultipleWirelessPointsResponse {
    /**
     *
     */
    public BulkTaskInfo task;

    public CreateMultipleWirelessPointsResponse task(BulkTaskInfo task) {
        this.task = task;
        return this;
    }
}
