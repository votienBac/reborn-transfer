package com.ringcentral.definitions;


public class CompanyAnsweringRuleExtensionInfo {
    /**
     * Internal identifier of an extension
     */
    public String id;

    public CompanyAnsweringRuleExtensionInfo id(String id) {
        this.id = id;
        return this;
    }
}
