package com.ringcentral.definitions;


public class AddDeviceToInventoryResponseDevices {
    /**
     * Internal identifier of a created device
     */
    public String id;

    public AddDeviceToInventoryResponseDevices id(String id) {
        this.id = id;
        return this;
    }
}
