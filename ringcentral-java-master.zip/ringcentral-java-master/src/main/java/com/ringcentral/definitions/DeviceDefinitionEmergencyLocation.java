package com.ringcentral.definitions;


public class DeviceDefinitionEmergencyLocation {
    /**
     * Emergency location ID
     */
    public String id;

    public DeviceDefinitionEmergencyLocation id(String id) {
        this.id = id;
        return this;
    }
}
